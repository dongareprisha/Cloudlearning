#!/bin/bash -xe
cd "$CODEBUILD_SRC_DIR"

terraform init -no-color
terraform $TF_ACTION -no-color -var-file=vars/$TF_VAR_ENV.tfvars -lock=false