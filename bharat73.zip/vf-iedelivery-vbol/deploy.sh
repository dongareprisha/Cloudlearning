#!/bin/bash -xe


export TF_VAR_ENV=$1
export TF_VAR_DEPLOY_ROLE=$2

cp terraform.tf terraform.tf.BACKUP
sed -i -e "s/{{ENV}}/$TF_VAR_ENV/" terraform.tf
sed -i '/dynamodb_table/d' terraform.tf
terraform init
terraform plan -var-file="config/$TF_VAR_ENV.tfvars"

mv terraform.tf.BACKUP terraform.tf

exit 0

