#!/bin/bash 
 
set -e 
 
export ROLE=$(echo "$DEPLOY_ROLE" | tr -d '"') 
 
cat > $CODEBUILD_SRC_DIR/aws <<EOL
[validate] 
role_arn = $ROLE 
region = eu-west-1
credential_source = EcsContainer 
EOL
 
export AWS_SHARED_CREDENTIALS_FILE=$CODEBUILD_SRC_DIR/aws  
 
cd "$CODEBUILD_SRC_DIR" 

pwd

ls


#vf-iedelivery-ci-cd-deployment-role/
printf "\nValidating vf-iedelivery-ci-cd-deployment-role/template.yml\n"
aws cloudformation validate-template --template-body file://vf-iedelivery-ci-cd-deployment-role/template.yml --profile validate
printf "Validating complete\n"

#vf-iedelivery-user-roles/
#/vf-iedelivery-stacksets/vf-iedelivery-user-roles/template.yml
printf "\nValidating vf-iedelivery-user-roles/template.yml\n"
aws s3api put-object --bucket vf-iedelivery-artifacts  --key cloudformation/vf-iedelivery-user-roles/template.yml --body vf-iedelivery-user-roles/template.yml
aws cloudformation validate-template --template-url https://vf-iedelivery-artifacts.s3-eu-west-1.amazonaws.com/cloudformation/vf-iedelivery-user-roles/template.yml  --profile validate 
printf "Validating complete\n"

#vf-iedelivery-logging/
printf "\nValidating vf-iedelivery-logging/template.yml\n"
aws cloudformation validate-template --template-body file://vf-iedelivery-logging/template.yml --profile validate 
printf "Validating complete\n"

#vf-iedelivery-eni-tagger/
printf "\nValidating vf-iedelivery-eni-tagger/template.yml\n"
aws cloudformation validate-template --template-body file://vf-iedelivery-eni-tagger/template.yml --profile validate 
printf "Validating complete\n"


#vf-iedelivery-config-aggregator/
printf "\nValidating vf-iedelivery-config-aggregator/template.yml\n"
aws cloudformation validate-template --template-body file://vf-iedelivery-config-aggregator/template.yml --profile validate 
printf "Validating complete\n"
