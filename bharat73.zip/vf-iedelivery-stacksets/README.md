# VFIE DELIVERY Stacksets 
 
## Introduction 
 
Repo containing stackset templates, scripts and other assets for deployment into/across the AWS estate for VFIE DELIVERY. 
 
Deployment is automated and occurs on changes to the master branch of this repo which is done via pull requests using AWS CodeCommit / CodePipeline 
 
Deployment is governed using the buildspec_deploy.yml file located in the root of the repo (do not delete this file) 
 
## Usage 
 
### Amending a template for an existing stackset 
 
* Navigate to relevant folder 
* Amend template 
* Validate template and check deployment using a DEV account to prevent deployment errors 
 
### Adding a new stackset 
 
* Create new folder with suitable name 
* Add/create template with deployment script as required 
* Validate template and check deployment using a DEV account to prevent deployment errors 
 
### Adding or removing an account/region to or from a stacket 
 
* The logic to determine which accounts/regions should have stack instances should be contained in the deployment script 
* This can include reading from a data file within the repo / DynamoDB 
* Based on the logic, stack instances can be created or deleted as required 
 
## Notes 
 
* Stacksets should always be stored/deployed in the eu-central-1 region.  
* Stack instances can be deloyed to accounts/regions as required using the deployment script 
* For templates, use YAML instead of JSON for better readability and more compact template files 
* Valid templates do not necessarily mean there will be no errors upon deployment. Check by always deploying in a DEV account first 
* Stacksets for common generic resources such as IAM roles for user access or deployment should be stored here 
* Templates relating to infrastructure / application solutions should be stored in separate repos 