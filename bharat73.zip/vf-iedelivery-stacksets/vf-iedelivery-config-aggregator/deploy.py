#!/usr/bin/env python

import os
import time
import json
import boto3
from pprint import pprint

global STACK_SET_NAME
STACK_SET_NAME = "vf-iedelivery-config-aggregator"

def handler():

    print("STARTING...")

    accounts = get_accounts()

    global all_account_ids
    all_account_ids = [a['id'] for a in accounts]

    session = boto3.Session(profile_name='deploy')

    global cf
    cf = session.client('cloudformation', region_name=os.environ['DEPLOY_REGION'])

    print("{} AWS account(s) to process!".format(len(accounts)))    

    check_stack_set()    
    check_stack_set_instances(all_account_ids)

    print("FINISHED!")

def check_stack_set_instances(account_ids):

    response = cf.list_stack_instances(StackSetName=STACK_SET_NAME)

    supported_account_ids = []
    unsupported_account_ids = []

    for item in response['Summaries']:

        if item['Status'] == 'INOPERABLE':
            print("Following stack instance requires manual investigation to fix!")
            pprint(item)
            print("Skipping account check for above stack instance....")
        elif item['Account'] in account_ids:
            supported_account_ids.append(item['Account'])
        else:
            unsupported_account_ids.append(item['Account'])

    if len(unsupported_account_ids) > 0:
        print("Stack instances unsupported for accounts: {}".format(unsupported_account_ids))
        delete_stack_set_instances(unsupported_account_ids)
    else:
        print("No stack instances in unsupported accounts")

    missing_account_ids = [x for x in account_ids if x not in supported_account_ids]

    if len(missing_account_ids) > 0:
        print("Stack instances missing for account(s): {}".format(missing_account_ids))
        create_stack_set_instances(missing_account_ids)
    else:
        print("No missing stack instances")

def delete_stack_set_instances(account_ids):

    check_stack_set_operations()

    print("Deleting stack set instances for tenants, {}".format(account_ids))

    response = cf.delete_stack_instances(
        StackSetName=STACK_SET_NAME,
        Accounts=account_ids,
        Regions=get_regions(),
        RetainStacks=False
    )

    print("Stack instances deleted, Operation Id: {}".format(response['OperationId']))

def create_stack_set_instances(missing_account_ids):

    check_stack_set_operations()
    print("Creating stack set instances for accounts: {}".format(missing_account_ids))

    accounts = []

    for account in get_accounts():
        account_id = account['id']
        if account_id in missing_account_ids:
            accounts.append(account_id)

    if len(accounts) > 0:
        check_stack_set_operations()
        print("{} account(s) missing stack instances".format(len(accounts)))
        response = cf.create_stack_instances(
            StackSetName=STACK_SET_NAME,
            Accounts=accounts,            
            Regions=get_regions(),
            OperationPreferences=get_operation_preferences()
        )

    print("New stack instances created, Operation Id: {}".format(response['OperationId']))

def check_stack_set():

    print("Checking whether stackset named {} exists".format(STACK_SET_NAME))
    
    description = 'VFIE DELIVERY - AWS config aggregator'
    
    with open('template.yml', 'r') as f:

        if active_stack_set_exists():

            print("STACK SET EXISTS! UPDATING.....")
            check_stack_set_operations()

            response = cf.update_stack_set(
                StackSetName=STACK_SET_NAME,
                Description=description,
                TemplateBody=f.read(),
                OperationPreferences=get_operation_preferences(),
                Capabilities=[ 'CAPABILITY_NAMED_IAM' ],
                Tags=get_tags()
            )

            print("UPDATE ISSUED: Operation Id: {}".format(response['OperationId']))

        else:

            print("STACK SET DOES NOT EXIST! CREATING.....")

            response = cf.create_stack_set(
                StackSetName=STACK_SET_NAME,
                Description=description,
                TemplateBody=f.read(),
                Capabilities=[ 'CAPABILITY_NAMED_IAM' ],
                Tags=get_tags()
            )

            print("CREATE ISSUED: StackSetId: {}".format(response['StackSetId']))    

    in_progress = True

    while in_progress:
        if active_stack_set_exists():
            in_progress = False
            print("Stackset named {} exists now!".format(STACK_SET_NAME))
        else:
            time.sleep(10)

# util functions#
def active_stack_set_exists():

    print("Checking whether stackset named {} exists/is ready".format(STACK_SET_NAME))

    stack_exists = False
    response = cf.list_stack_sets()

    for item in response['Summaries']:
        if item['StackSetName'] == STACK_SET_NAME and item['Status'] == 'ACTIVE':
            stack_exists = True            
            break

    return stack_exists

def check_stack_set_operations(show_msg=True):

    if show_msg:
        print("Checking that stack set has no running/stopping operations")

    response = cf.list_stack_set_operations(StackSetName=STACK_SET_NAME)

    blocking_operations = [x for x in response['Summaries'] if x['Status'] in ['RUNNING', 'STOPPING'] ]

    if len(blocking_operations) > 0:
        wait_period = 30        
        print("Stack set operation(s) running or stopping. Retrying in {} seconds....".format(wait_period))
        time.sleep(wait_period)
        return check_stack_set_operations(False)
    else:
        print("No stack set operations running now. Continue with stack set operations")

def get_accounts():

    accounts = [
        {'id' : '046978237480', 'name': 'vf-iedelivery-test-01'},
        {'id' : '461886926508', 'name': 'vf-iedelivery-test-02'},
        {'id' : '782212824980', 'name': 'vf-iedelivery-test-03'},
        {'id' : '294086262004', 'name': 'vf-iedelivery-test-04'},
        {'id' : '612841682649', 'name': 'vf-iedelivery-preprod-01'},
        {'id' : '516166671208', 'name': 'vf-iedelivery-preprod-02'},
        {'id' : '323874256692', 'name': 'vf-iedelivery-prod-01'},
        {'id' : '299879056526', 'name': 'vf-iedelivery-sandbox-01'},
        {'id' : '831341508773', 'name': 'vf-iedelivery-mgmt'},
        {'id' : '267040142128', 'name': 'vf-iedelivery-prod-ss-01'},
        {'id' : '017361906891', 'name': 'vf-iedelivery-dev-01'},
        {'id' : '687158677620', 'name': 'vf-iedelivery-eks-test-01'},
        {'id' : '617458290184', 'name': 'vf-iedelivery-eks-test-02'},
        {'id' : '483246254322', 'name': 'vf-iedelivery-eks-test-03'},
        {'id' : '701287184434', 'name': 'vf-iedelivery-eks-test-04'},
        {'id' : '387095844067', 'name': 'vf-iedelivery-eks-preprod'},
        {'id' : '762937892420', 'name': 'vf-iedelivery-eks-preprod-02'},
        {'id' : '466441119255', 'name': 'vf-iedelivery-eks-prod'},
        {'id' : '607188850947', 'name': 'vf-iedelivery-eks-dev-01'},
        {'id' : '702435862819', 'name': 'vf-iedelivery-pmx-dev-01'},
        {'id' : '277053435657', 'name': 'vf-iedelivery-pmx-test-01'},
        {'id' : '669135975699', 'name': 'vf-iedelivery-pmx-test-02'},
        {'id' : '684605070964', 'name': 'vf-iedelivery-pmx-test-03'},
        {'id' : '096245185585', 'name': 'vf-iedelivery-pmx-test-04'},
        {'id' : '645707254813', 'name': 'vf-iedelivery-pmx-preprod-01'},
        {'id' : '297948665209', 'name': 'vf-iedelivery-pmx-preprod-02'},
        {'id' : '315431096082', 'name': 'vf-iedelivery-pmx-prod-01'}        
    ]

    return accounts

def get_operation_preferences():
    return {
        'RegionOrder': get_regions(),
        'FailureTolerancePercentage': 0,
        'MaxConcurrentPercentage': 100
    }

def get_tags():

    tags = {
        'Environment' : 'PROD',
        'Project' : 'VF-IEDELIVERY',
        'Repository' : 'vf-iedelivery-stacksets',
        'TaggedBy': "gdc-pcs-eni-tagging-lambda",
        'BusinessService' : "VF-PUBLIC CLOUD-AWS",
        'ApplicationEnvironment': 'PROD',
        'ManagedBy' : 'DL-GDC-PLT-SVCS-Public-Cloud-Managed-Services@vodafone.com',
        'Confidentiality' : 'C3',
        'SecurityZone': "A",
        'ApplicationName': "VF-IEDELIVERY",
        'TaggingVersion' : 'V2.4'
    }

    result = []

    for key in tags:
        result.append({
            'Key' : str(key),
            'Value' : str(tags[key])
        })

    return result

def get_regions():
    return ['eu-west-1']

handler()