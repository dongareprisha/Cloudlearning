#!/bin/bash 
 
set -e 
 
export ROLE=$(echo "$DEPLOY_ROLE" | tr -d '"') 
 
cat > $CODEBUILD_SRC_DIR/aws <<EOL 
[deploy] 
role_arn = $ROLE 
region = eu-west-1
credential_source = EcsContainer 
EOL

export AWS_SHARED_CREDENTIALS_FILE=$CODEBUILD_SRC_DIR/aws  

#vf-iedelivery-ci-cd-deployment-role/
printf "\nDeploying vf-iedelivery-ci-cd-deployment-role/deploy.py\n"
cd "$CODEBUILD_SRC_DIR/vf-iedelivery-ci-cd-deployment-role" 
python deploy.py 
printf "Finished vf-iedelivery-ci-cd-deployment-role/deploy.py\n"

#vf-iedelivery-user-roles/
printf "\nDeploying vf-iedelivery-user-roles/deploy.py\n"
cd "$CODEBUILD_SRC_DIR/vf-iedelivery-user-roles" 
python deploy.py
printf "Finished vf-iedelivery-user-roles/deploy.py\n"

#vf-iedelivery-logging/
printf "\nDeploying vf-iedelivery-logging/deploy.py\n"
cd "$CODEBUILD_SRC_DIR/vf-iedelivery-logging" 
python deploy.py
printf "Finished vf-iedelivery-logging/deploy.py\n"

#vf-iedelivery-eni-tagger/
printf "\nDeploying vf-iedelivery-eni-tagger/deploy.py\n"
cd "$CODEBUILD_SRC_DIR/vf-iedelivery-eni-tagger" 
python deploy.py
printf "Finished vf-iedelivery-eni-tagger/deploy.py\n"


#vf-iedelivery-config-aggregator/
printf "\nDeploying vf-iedelivery-config-aggregator/deploy.py\n"
cd "$CODEBUILD_SRC_DIR/vf-iedelivery-config-aggregator" 
python deploy.py
printf "Finished vf-iedelivery-config-aggregator/deploy.py\n"
