import boto3
from datetime import datetime, timezone
import os
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Environment variables (set in Terraform)
TARGET_USER = os.environ.get('TARGET_USER')
TOPIC_ARN = os.environ.get('TOPIC_ARN')

def lambda_handler(event, context):
    logger.info("Lambda function started")
    logger.info(f"Checking access keys for IAM user: {TARGET_USER}")
    
    iam = boto3.client('iam')
    sns = boto3.client('sns')

    try:
        keys = iam.list_access_keys(UserName=TARGET_USER)['AccessKeyMetadata']
        logger.info(f"Found {len(keys)} access key(s) for user {TARGET_USER}")
        
        for key in keys:
            create_date = key['CreateDate']
            age = (datetime.now(timezone.utc) - create_date).days
            logger.info(f"Access key {key['AccessKeyId']} is {age} days old")

            if age >= 85:
                message = (
                    f"Access key for IAM user '{TARGET_USER}' is {age} days old.\n"
                    f"Access Key ID: {key['AccessKeyId']}\n"
                    "Please rotate the key to maintain security best practices."
                )
                logger.info("Publishing alert to SNS")
                sns.publish(
                    TopicArn=TOPIC_ARN,
                    Subject='IAM Access Key Expiry Alert',
                    Message=message
                )
            else:
                logger.info(f"Access key {key['AccessKeyId']} does not meet threshold for alert")
    except Exception as e:
        logger.error(f"Error checking access keys for {TARGET_USER}: {e}")
