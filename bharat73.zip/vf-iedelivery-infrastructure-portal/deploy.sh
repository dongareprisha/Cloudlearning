#!/bin/bash -xe

cd "$CODEBUILD_SRC_DIR"

case $TF_VAR_ENV in
  PROD )
    mv 2-prod.tf_ 2-prod.tf
    ;;
  PRE-PROD )
    mv 2-preprod.tf_ 2-preprod.tf
    ;;
  PRE-PROD2 )
    mv 2-preprod2.tf_ 2-preprod2.tf
    ;;
  TEST )
    mv 2-test.tf_ 2-test.tf
    ;;
  TEST2 )
    mv 2-test2.tf_ 2-test2.tf
    ;;
  TEST3 )
    mv 2-test3.tf_ 2-test3.tf
    ;;
  TEST4 )
    mv 2-test4.tf_ 2-test4.tf
    ;;
  DEV )
    mv 2-dev.tf_ 2-dev.tf
    ;;
esac


cd "$CODEBUILD_SRC_DIR"

sed -i -e "s/{{ENV}}/$TF_VAR_ENV/" backend.tf

terraform init -no-color
terraform $TF_ACTION -no-color -var-file=vars/$TF_VAR_ENV.tfvars