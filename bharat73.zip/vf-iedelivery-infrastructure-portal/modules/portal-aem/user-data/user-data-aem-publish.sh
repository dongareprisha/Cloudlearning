#!/bin/bash
 
mkdir -p /u01/app/software
chown ieadm:ieadm /u01/app/software
EFS_FILE_SYSTEM_ID=${SoftwareEFS}
DIR_SRC=${SoftwareEFS}.efs.${Region}.amazonaws.com
 
# DIR_TGT=/u01/app
DIR_TGT=/u01/app/software
 
# Creating backup file for /etc/fstab
cp -p /etc/fstab /etc/fstab.back-$(date +%F)
 
mount -t nfs4 -o nfsvers=4.1,rsize=1048576,wsize=1048576,hard,timeo=600,retrans=2,noresvport ${SoftwareEFS}.efs.eu-west-1.amazonaws.com:/software/ $DIR_TGT
 
# Automating EFS Partition Mounting
echo -e "$DIR_SRC:/software/ \t\t $DIR_TGT \t\t nfs4 \t\t nfsvers=4.1,rsize=1048576,wsize=1048576,hard,timeo=600,retrans=2 \t\t 0 \t\t 0" | tee -a /etc/fstab
 
##CW AGENT
instance_id=$(wget -q -O - http://169.254.169.254/latest/meta-data/instance-id)
sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -s -c ssm:${ssm_parameter}
sudo userdel -r cwagent
 
# backup limits.conf
sudo cp /etc/security/limits.conf ~/limits.conf.bak
# increase open file limits
sudo cat << EOF >> /etc/security/limits.conf
# Added per Oracle and Celfocus recommendations
* soft  nofile  8192
* hard  nofile  65536
* soft  nproc   8192
* hard  nproc   16384
* soft  sigpending   257576
* hard  sigpending   257576
* soft  stack   10240
* hard  stack   unlimited
EOF

# Activate Qualys Agent
service qualys-cloud-agent stop
/usr/local/qualys/cloud-agent/bin/qualys-cloud-agent.sh ActivationId=6f5d2eec-ba86-443c-88af-07a394fc3148 CustomerId=3f751192-e92e-d42e-83ce-c5a54f519118

# Configure Appdynamics
cat<<EOT | tee /u01/app/appagent/ver4.4.1.0/conf/controller-info.xml /u01/app/appagent/conf/controller-info.xml /u01/app/ohsagent/appdynamics_generic/appdynamics-sdk-native/proxy/conf/controller-info.xml
<controller-info>
    <controller-host>${env}.haproxy.ieaws.vodafone.com</controller-host>
    <controller-port>29001</controller-port>
    <application-name>AWS-IEPORTAL-${ENV}</application-name>
    <tier-name>IEPORTAL-AEM-PUBLISHER</tier-name>
    <node-name>ieportal-aem-publish${node_id}.${env}.ieaws.vodafone.com</node-name>
    <account-name>customer1</account-name>
    <account-access-key>f4d38fbc-931e-4705-ab8c-5c7166eb7e97</account-access-key>
</controller-info>
EOT