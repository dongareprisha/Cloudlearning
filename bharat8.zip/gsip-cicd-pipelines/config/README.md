# `config/`

Stores the Terraform variable files for the different environments e.g. DEV, PROD etc.

## `ENV`.tfvars

Stores the variable assignments from variables defined in `../terraform/variables.tf`. These variable files follow the naming convention of: `${ENV}.tfvars`

`ENV` is a CodeBuild environment variable populated at CodeBuild runtime. This is passed in via the `environments` variable object, specifically the key of each object. For example:

```hcl
module "project_name" {

  source = "../modules/terraform-pipeline"

  repository_name = "repo_name" #replace with final name of the repo where all pipelines will be defined
  environments = {
    PROD = {
      account_id    = ["123456789012"]
      pipeline_role = "pipeline-deployment-role"
      branch        = "main"
    },
    PRE-PROD = {
      account_id    = ["456789012345"]
      pipeline_role = "pipeline-deployment-role"
      branch        = "pre-prod"
    }
  }
}
```

In the case above:

* `PROD` is the value for `ENV` for the production pipeline for the repo specified in the `repository_name` variable
* `PRE-PROD` is the value for `ENV` for the pre-prod pipeline for the repo specified in the `repository_name` variable

As a result, you need to ensure that your variable files (`*.tfvars`) in the repo are named accordingly. i.e. `PROD.tfvars`.
