# terraform-pipeline Terraform module

Creates a CodePipeline pipeline for use in deploying resources defined via Terraform.

## Code Analysis Tool Report

The Terraform code has been scanned using tfsec and checkov. These checks are part of a pipeline to help ensure configurations for resources conform to industry best practices. Additionally, they can also be used to define custom requirements using policy-as-code for custom checks.

### tfsec

* **ID:** [aws-iam-no-policy-wildcards](https://aquasecurity.github.io/tfsec/latest/checks/aws/iam/no-policy-wildcards)
  * **Violation Location(s):** [`0-iam.tf:167-181`](./0-iam.tf),[`0-iam.tf:250-264`](./0-iam.tf)
  * **Ignore Justification:** This policy is required for CodeBuild projects to log their output to CloudWatch logs. Any changes to the `*` in `Resources` will result in CodeBuild not working at all.

## Instantiating the Module

The module can be called like this:

```
module "main_pipeline" {

  source = "./modules/terraform-pipeline"

  repository_name = "myproj_resources"
  environments = {
    PROD = {
      account_id    = ["123456789012"]
      pipeline_role = "cicd-deployment-role"
      branch        = "main"
      pipeline_approvers = {
        "pcs-approval" = ""
      }
    }
  }
}
```
This will create a brand new Terraform pipeline for use with the repository configured in `repository_name`.

### Changing the Approvers

Given the example above, `pipeline_approvers` can be configured to create ***n*** approvers, with an optional SNS topic ARN to be used so a notification can be sent to endpoints in the SNS topic letting subscribers know there is an approval awaiting their actions. For example:

```terraform
module "<project_name>_pipeline" {

  source = "./modules/terraform-pipeline"

  repository_name = "my-repo-name"
  environments = {
    PROD = {
      account_id    = ["123456789012"]
      pipeline_role = "ci-cd-deployment-role"
      branch        = "main"
      pipeline_approvers = {
        "devops-approval" = ""
        "security-approval = "<SNS_TOPIC_ARN>"
      }
    }
    PRE-PROD = {
      account_id    = ["345678901234"]
      pipeline_role = "ci-cd-deployment-role"
      branch        = "pre-prod"
      pipeline_approvers = {
        "devopslead-approval" = ""
      }
    }
    DEV = {
      account_id    = ["567890123456"]
      pipeline_role = "ci-cd-deployment-role"
      branch        = "dev"
      pipeline_approvers = {
        "devops-approval" = ""
      }
    }
  }
}
```

The PROD pipeline will have two approvers, named:

* devops-approval
* security-approval

with `security-approval` having an SNS topic associated with it. This means when `security-approval` is reached, the endpoints associated with the SNS topic would get a notification, and the subscribers would be notified that there is an approval awaiting their review. The `devops-approval` approval action has no SNS topic ARN specified, so no notifications are sent for that specific approval action.

If an SNS topic is specified for any of the approvers in `pipeline_approvers`, an additional IAM role policy (`codepipeline_sns_manual_approvals`) is created for the CodePipeline IAM role that gives it permissions to `sns:Publish` to the SNS topic arns specified as the value of `pipeline_approvers` keys.

Each manual approval action when interacted with via the AWS Console will present a basic message to them, a direct link to the specific commit being pushed through the pipeline via its unique hash using CodeCommit. For those approval actions that have an SNS topic associated, this information will be sent in the SNS notification to the endpoints subscribed to the SNS topic. You can view this in the [`2-codepipeline.tf`](./2-codepipeline.tf) file or below:

```terraform
#<...>
configuration = {
  NotificationArn    = approver.value != "" ? approver.value : null
  ExternalEntityLink = "https://${data.aws_region.current.name}.console.aws.amazon.com/codesuite/codecommit/repositories/#{SourceVariables.RepositoryName}/commit/#{SourceVariables.CommitId}?region=${data.aws_region.current.name}"
  CustomData         = "A change has been requested on the '#{SourceVariables.BranchName}' branch for the repository '#{SourceVariables.RepositoryName}' and requires pipeline approval. Commit Message: #{SourceVariables.CommitMessage}"
}
#<...>
```

As you can see, it uses the `SourceVariables` namespace from the CodeCommit action which provides several variables for consumption. In this particular module, we are using the:

1. `SourceVariables.RepositoryName`
2. `SourceVariables.CommitId`
3. `SourceVariables.BranchName`
4. `SourceVariables.CommitMessage`

variables. This ensures that when new modules are created they are using the right variables with the right values dynamically, without human intervention required. You can find more info about this [here](https://docs.aws.amazon.com/codepipeline/latest/userguide/reference-variables.html) if you're interested.

It is also important to note that the reviewer still has to log into the AWS account and have the correct permissions to be able to actually approve the action. This is just a notification.

The PRE-PROD pipeline would have just one approver, named:

* devopslead-approval

with the DEV pipeline also having one approver, named:

* devops-approval

### Omitting pipeline_approvers

If `pipeline_approvers` is empty, like this:

```diff
module "dns_pipeline" {

  source = "./modules/terraform-pipeline"

  repository_name = "my-repo-name-dns"
  environments = {
    PROD = {
      account_id    = ["123456789012", "345678901234", "567890123456"]
      pipeline_role = "ci-cd-deployment-role"
      branch        = "main"
+     pipeline_approvers = {}
    }
  }
}
```

then a default manual approval step named: `approval` will be created in all pipelines to prevent situations where if a Terraform plan is successful, it goes straight into the Apply stage without review.

### Deploying resources to multiple accounts through one pipeline

If you want to deploy resources to multiple accounts through a single pipeline, such as managing user IAM, you can specify multiple AWS account IDs in the `account_id` variable. For example:

```terraform
module "iam_pipeline" {

  source = "./modules/terraform-pipeline"

  repository_name = "myproj-shared-iam"
  environments = {
    PROD = {
      account_id    = ["123456789012", "345678901234", "567890123456"]
      pipeline_role = "ci-cd-deployment-role-iam"
      branch        = "main"
      pipeline_approvers = {
        "pcs-approval" = ""
        "security-approval = "<SNS_TOPIC_ARN>"
      }
    }
  }
}
```

Doing this will ensure the assume role policy for the Code Deployment CodeBuild IAM Roles has the ability to assume role to the accounts specified above via the `ci-cd-deployment-role-iam`, so:

```diff
+ arn:aws:iam::123456789012/ci-cd-deployment-role-iam
+ arn:aws:iam::345678901234/ci-cd-deployment-role-iam
+ arn:aws:iam::567890123456/ci-cd-deployment-role-iam
```

If using this method, the repository, which in this example is `myproj-shared-iam` would have to contain multiple `provider "aws" {}` blocks, that are aliased via `alias` and each contain a unique `assume_role` block within, that are essentially those ARNs shown above.

## Other Configurations

### Terraform Parallelism

By default, the parallelism for Terraform is set to `10`. For environments where there is a long plan/apply, increasting this can be used to potenitally speed up the time it takes. This can be done by setting the `tf_parallelism` variable to a different value from the default `10`. This is then passed to the `TF_CLI_ARGS_plan` and `TF_CLI_ARGS_apply` CodeBuild environment variables so when the next Terraform Plan/Apply is ran, it will use the new values.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_random"></a> [random](#requirement\_random) | ~> 3.1.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_random"></a> [random](#provider\_random) | ~> 3.1.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_cloudwatch_event_rule.trigger](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_rule) | resource |
| [aws_cloudwatch_event_target.trigger](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_target) | resource |
| [aws_codebuild_project.checkov](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/codebuild_project) | resource |
| [aws_codebuild_project.tf_apply](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/codebuild_project) | resource |
| [aws_codebuild_project.tf_plan](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/codebuild_project) | resource |
| [aws_codebuild_project.tflint](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/codebuild_project) | resource |
| [aws_codebuild_project.tfsec](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/codebuild_project) | resource |
| [aws_codepipeline.pipeline](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/codepipeline) | resource |
| [aws_iam_role.codebuild_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.codechecks_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.codepipeline_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.cw_events_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role_policy.assume_deployment_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.cicd_artifact_use](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.codechecks_cicd_artifact_use](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.codechecks_log_to_cloudwatch](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.codepipeline_cicd_artifact_use](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.codepipeline_repo_access](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.codepipeline_sns_manual_approvals](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.codepipeline_trigger_codebuild](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.log_to_cloudwatch](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.start_pipeline_execution](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.terraform_backend_access](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [random_string.unique_resource_suffix](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [aws_ssm_parameter.artifact_bucket](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ssm_parameter) | data source |
| [aws_ssm_parameter.cmk_arn](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ssm_parameter) | data source |
| [aws_ssm_parameter.locks_table_arn](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ssm_parameter) | data source |
| [aws_ssm_parameter.remote_state_bucket](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ssm_parameter) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_build_image"></a> [build\_image](#input\_build\_image) | CodeBuild image used to spin up CodeBuild Container | `string` | `"aws/codebuild/standard:5.0"` | no |
| <a name="input_checkov_build_timeout"></a> [checkov\_build\_timeout](#input\_checkov\_build\_timeout) | In minutes. Length of time checkov-scan CodeBuild project can run before timeout. | `string` | `"60"` | no |
| <a name="input_checkov_builspec"></a> [checkov\_builspec](#input\_checkov\_builspec) | file path to the location of the buildspec file used for the checkov-scan CodeBuild action | `string` | `"buildspec/checkov.yml"` | no |
| <a name="input_environments"></a> [environments](#input\_environments) | Used to created multiple pipelines off of the same repo but different branches and configure pipeline approvers | <pre>map(object({<br>    account_id         = list(string)<br>    pipeline_role      = string<br>    branch             = string<br>    pipeline_approvers = map(string)<br>  }))</pre> | n/a | yes |
| <a name="input_repository_name"></a> [repository\_name](#input\_repository\_name) | Name of the CodeCommit repo | `string` | n/a | yes |
| <a name="input_terraform_buildspec"></a> [terraform\_buildspec](#input\_terraform\_buildspec) | file path to the location of the buildspec file used for the terraform plan/apply CodeBuild actions | `string` | `"buildspec/terraform.yml"` | no |
| <a name="input_tf_parallelism"></a> [tf\_parallelism](#input\_tf\_parallelism) | Limit the number of concurrent operation as Terraform walks the graph. Can potenitally speed up slow plan/applies. | `number` | `10` | no |
| <a name="input_tfapply_build_timeout"></a> [tfapply\_build\_timeout](#input\_tfapply\_build\_timeout) | In minutes. Length of time terraform-apply CodeBuild project can run before timeout. | `string` | `"60"` | no |
| <a name="input_tflint_build_timeout"></a> [tflint\_build\_timeout](#input\_tflint\_build\_timeout) | In minutes. Length of time tflint-scan CodeBuild project can run before timeout. | `string` | `"60"` | no |
| <a name="input_tflint_buildspec"></a> [tflint\_buildspec](#input\_tflint\_buildspec) | file path to the location of the buildspec file used for the tflint-scan CodeBuild action | `string` | `"buildspec/tflint.yml"` | no |
| <a name="input_tfplan_build_timeout"></a> [tfplan\_build\_timeout](#input\_tfplan\_build\_timeout) | In minutes. Length of time terraform-plan CodeBuild project can run before timeout. | `string` | `"60"` | no |
| <a name="input_tfsec_build_timeout"></a> [tfsec\_build\_timeout](#input\_tfsec\_build\_timeout) | In minutes. Length of time tfsec-scan CodeBuild project can run before timeout. | `string` | `"60"` | no |
| <a name="input_tfsec_buildspec"></a> [tfsec\_buildspec](#input\_tfsec\_buildspec) | file path to the location of the buildspec file used for the tfsec-scan CodeBuild action | `string` | `"buildspec/tfsec.yml"` | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->