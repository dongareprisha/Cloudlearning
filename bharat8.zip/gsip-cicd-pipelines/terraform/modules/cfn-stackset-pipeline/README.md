# cfn-pipeline Terraform module

Creates a CodePipeline pipeline for use in deploying CloudFormation StackSets using a Python deployment script to manage StackSets deployment logic.

## Code Analysis Tool Report

The Terraform code has been scanned using tfsec and checkov. These checks are part of a pipeline to help ensure configurations for resources conform to industry best practices. Additionally, they can also be used to define custom requirements using policy-as-code for custom checks.

### tfsec

* **ID:** [aws-iam-no-policy-wildcards](https://aquasecurity.github.io/tfsec/latest/checks/aws/iam/no-policy-wildcards)
  * **Violation Location(s):** [`0-iam.tf:212-226`](./0-iam.tf),[`0-iam.tf:129-143`](./0-iam.tf)
  * **Ignore Justification:** This policy is required for CodeBuild projects to log their output to CloudWatch logs. Any changes to the `*` in `Resources` will result in CodeBuild not working at all.

## Instantiating the Module

The module can be called like this:

```
module "main_pipeline" {

  source = "./modules/cfn-pipeline"

  repository_name = "myproj_stacksets"
  environments = {
    PROD = {
      account_id    = ["123456789012"]
      pipeline_role = "cicd-deployment-role"
      branch        = "main"
      pipeline_approvers = {
        "pcs-approval" = ""
      }
    }
  }
}
```
This will create a brand new CloudFormation StackSet pipeline for use with the repository configured in `repository_name`, such as `<project_name>_stacksets`.

### Changing the Approvers

Given the example above, `pipeline_approvers` can be configured to create ***n*** approvers, with an optional SNS topic ARN to be used so a notification can be sent to endpoints in the SNS topic letting subscribers know there is an approval awaiting their actions. For example:

```terraform
module "<project_name>_pipeline" {

  source = "./modules/cfn-pipeline"

  repository_name = "myproj-stacksets"
  environments = {
    PROD = {
      account_id    = ["123456789012"]
      pipeline_role = "ci-cd-deployment-role"
      branch        = "main"
      pipeline_approvers = {
        "devops-approval" = ""
        "security-approval = "<SNS_TOPIC_ARN>"
      }
    }
  }
}
```

The PROD pipeline will have two approvers, named:

* devops-approval
* security-approval

with `security-approval` having an SNS topic associated with it. This means when `security-approval` is reached, the endpoints associated with the SNS topic would get a notification, and the subscribers would be notified that there is an approval awaiting their review. The `devops-approval` approval action has no SNS topic ARN specified, so no notifications are sent for that specific approval action.

If an SNS topic is specified for any of the approvers in `pipeline_approvers`, an additional IAM role policy (`codepipeline_sns_manual_approvals`) is created for the CodePipeline IAM role that gives it permissions to `sns:Publish` to the SNS topic arns specified as the value of `pipeline_approvers` keys.

Each manual approval action when interacted with via the AWS Console will present a basic message to them, a direct link to the specific commit being pushed through the pipeline via its unique hash using CodeCommit. For those approval actions that have an SNS topic associated, this information will be sent in the SNS notification to the endpoints subscribed to the SNS topic. You can view this in the [`2-codepipeline.tf`](./2-codepipeline.tf) file or below:

```terraform
#<...>
configuration = {
  NotificationArn    = approver.value != "" ? approver.value : null
  ExternalEntityLink = "https://${data.aws_region.current.name}.console.aws.amazon.com/codesuite/codecommit/repositories/#{SourceVariables.RepositoryName}/commit/#{SourceVariables.CommitId}?region=${data.aws_region.current.name}"
  CustomData         = "A change has been requested on the '#{SourceVariables.BranchName}' branch for the repository '#{SourceVariables.RepositoryName}' and requires pipeline approval. Commit Message: #{SourceVariables.CommitMessage}"
}
#<...>
```

As you can see, it uses the `SourceVariables` namespace from the CodeCommit action which provides several variables for consumption. In this particular module, we are using the:

1. `SourceVariables.RepositoryName`
2. `SourceVariables.CommitId`
3. `SourceVariables.BranchName`
4. `SourceVariables.CommitMessage`

variables. This ensures that when new modules are created they are using the right variables with the right values dynamically, without human intervention required. You can find more info about this [here](https://docs.aws.amazon.com/codepipeline/latest/userguide/reference-variables.html) if you're interested.

It is also important to note that the reviewer still has to log into the AWS account and have the correct permissions to be able to actually approve the action. This is just a notification.

The PRE-PROD pipeline would have just one approver, named:

* devops-approval

As StackSets are typiucally deployed into multiple accounts, this process is handled within the StackSets repo itself, and not at the module level.

### Omitting pipeline_approvers

If `pipeline_approvers` is empty, like this:

```diff
module "dns_pipeline" {

  source = "./modules/cfn-pipeline"

  repository_name = "my-repo-name-dns"
  environments = {
    PROD = {
      account_id    = ["123456789012", "345678901234", "567890123456"]
      pipeline_role = "ci-cd-deployment-role"
      branch        = "main"
+     pipeline_approvers = {}
    }
  }
}
```

then a default manual approval step named: `approval` will be created in all pipelines to prevent a StackSet deploy without checking the results of the previous CodeBuild actions.
<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_random"></a> [random](#requirement\_random) | ~> 3.1.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_random"></a> [random](#provider\_random) | ~> 3.1.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_cloudwatch_event_rule.trigger](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_rule) | resource |
| [aws_cloudwatch_event_target.trigger](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_target) | resource |
| [aws_codebuild_project.cf_deploy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/codebuild_project) | resource |
| [aws_codebuild_project.cf_validate](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/codebuild_project) | resource |
| [aws_codebuild_project.cfn_lint](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/codebuild_project) | resource |
| [aws_codebuild_project.checkov](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/codebuild_project) | resource |
| [aws_codepipeline.pipeline](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/codepipeline) | resource |
| [aws_iam_role.codebuild_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.codechecks_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.codepipeline_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.cw_events_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role_policy.assume_deployment_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.cicd_artifact_use](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.codechecks_cicd_artifact_use](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.codechecks_log_to_cloudwatch](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.codepipeline_cicd_artifact_use](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.codepipeline_repo_access](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.codepipeline_sns_manual_approvals](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.codepipeline_trigger_codebuild](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.log_to_cloudwatch](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.start_pipeline_execution](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [random_string.unique_resource_suffix](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [aws_ssm_parameter.artifact_bucket](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ssm_parameter) | data source |
| [aws_ssm_parameter.cmk_arn](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ssm_parameter) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_build_image"></a> [build\_image](#input\_build\_image) | CodeBuild image used to spin up CodeBuild Container | `string` | `"aws/codebuild/standard:5.0"` | no |
| <a name="input_cf_deploy_build_timeout"></a> [cf\_deploy\_build\_timeout](#input\_cf\_deploy\_build\_timeout) | In minutes. Length of time cf-deploy CodeBuild project can run before timeout. | `string` | `"60"` | no |
| <a name="input_cf_deploy_buildspec"></a> [cf\_deploy\_buildspec](#input\_cf\_deploy\_buildspec) | file path to the location of the buildspec file used for the cloudformation deploy CodeBuild action | `string` | `"buildspec/cf_deploy.yml"` | no |
| <a name="input_cf_validate_build_timeout"></a> [cf\_validate\_build\_timeout](#input\_cf\_validate\_build\_timeout) | In minutes. Length of time cf-validate CodeBuild project can run before timeout. | `string` | `"60"` | no |
| <a name="input_cf_validate_buildspec"></a> [cf\_validate\_buildspec](#input\_cf\_validate\_buildspec) | file path to the location of the buildspec file used for the cloudformation validate CodeBuild action | `string` | `"buildspec/cf_validate.yml"` | no |
| <a name="input_cfn_lint_build_timeout"></a> [cfn\_lint\_build\_timeout](#input\_cfn\_lint\_build\_timeout) | In minutes. Length of time cfn-lint CodeBuild project can run before timeout. | `string` | `"60"` | no |
| <a name="input_cfn_lint_buildspec"></a> [cfn\_lint\_buildspec](#input\_cfn\_lint\_buildspec) | file path to the location of the buildspec file used for the cfnlint-scan CodeBuild action | `string` | `"buildspec/cfnlint.yml"` | no |
| <a name="input_checkov_build_timeout"></a> [checkov\_build\_timeout](#input\_checkov\_build\_timeout) | In minutes. Length of time checkov CodeBuild project can run before timeout. | `string` | `"60"` | no |
| <a name="input_checkov_buildspec"></a> [checkov\_buildspec](#input\_checkov\_buildspec) | file path to the location of the buildspec file used for the checkov-scan CodeBuild action | `string` | `"buildspec/checkov.yml"` | no |
| <a name="input_environments"></a> [environments](#input\_environments) | Used to created multiple pipelines off of the same repo but different branches and configure pipeline approvers | <pre>map(object({<br>    account_id         = list(string)<br>    pipeline_role      = string<br>    branch             = string<br>    pipeline_approvers = map(string)<br>  }))</pre> | n/a | yes |
| <a name="input_repository_name"></a> [repository\_name](#input\_repository\_name) | Name of the CodeCommit repo | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->