# terraform

Deploys shared resources required as part of the PCS-1517 Customer Infrastructure CI/CD using CodeBuild service. These are resources are required by the `./modules` to ensure encryption, artefact, Terraform remote state management and an S3 server access logging bucket are created for a pipeline to function correctly and securely.

## Code Analysis Tool Report

The Terraform code has been scanned using tfsec and checkov. These checks are part of a pipeline to help ensure configurations for resources conform to industry best practices. Additionally, they can also be used to define custom requirements using policy-as-code for custom checks.

### tfsec

* **ID:** [aws-dynamodb-enable-recovery](https://aquasecurity.github.io/tfsec/latest/checks/aws/dynamodb/enable-recovery)
  * **Violation Location(s):**
    * [`ddb.tf | resource "aws_dynamodb_table" "locks_table"`](./ddb.tf)
  * **Ignore Justification:** The DynamoDB table is only required for Terraform state lock management, and the pipelines are configured so that there can only ever be one Terraform run at a time. Even if the lock disappeared, Terraform would create a new one and populate the table on the next Terraform run. Therefore, PCS think the additional cost of this feature is not worth it due to the very low risk.

* **ID:** [aws-dynamodb-table-customer-key](https://aquasecurity.github.io/tfsec/latest/checks/aws/dynamodb/table-customer-key)
  * **Violation Location(s):**
    * [`ddb.tf | resource "aws_dynamodb_table" "locks_table"`](./ddb.tf)
  * **Ignore Justification:** The DynamoDB table only contains locks and the md5 checksum for the Terraform state files. As this data is not sensitive, and everything in DynamoDB is encrypted at rest by default, PCS believe the additonal costs and complexity of using KMS are not worth it for consumers.

* **ID:** [aws-dynamodb-enable-at-rest-encryption](https://aquasecurity.github.io/tfsec/v0.61.3/checks/aws/dynamodb/enable-at-rest-encryption/)
  * **Violation Location(s):**
    * [`ddb.tf | resource "aws_dynamodb_table" "locks_table"`](./ddb.tf)
  * **Ignore Justification:** This rule seems to be affiliated with DynamoDB Accelerator (DAX), specifically the `aws_dax_cluster` resource, which is not used in this solution and thus is deemed a false positive. As mentioned previously everything in DynamoDB is encrypted at rest by default, PCS believe the additonal costs and complexity of using KMS are not worth it for consumers.

### checkov

* **ID:** [CKV2_AWS_16 - Ensure that Auto Scaling is enabled on your DynamoDB tables](https://www.checkov.io/5.Policy%20Index/terraform.html)
  * **Violation Location(s):**
    * [`ddb.tf | resource "aws_dynamodb_table" "locks_table"`](./ddb.tf)
  * **Ignore Justification:** The DynamoDB table is only required for Terraform state lock management, and is not expected to be written to very heavily that would warrant scaling. Based on the additional cost of this feature, PCS believes this is not warranted.

* **ID:** [CKV_AWS_28 - Ensure Dynamodb point in time recovery (backup) is enabled](https://www.checkov.io/5.Policy%20Index/terraform.html)
  * **Violation Location(s):**
    * [`ddb.tf | resource "aws_dynamodb_table" "locks_table"`](./ddb.tf)
  * **Ignore Justification:** The DynamoDB table is only required for Terraform state lock management, and Terraform will still function if these lock files are deleted, and will be populated again on the next pipeline run. Furthermore, each Terraform pipeline run can only happen one at a time (i.e. the plan and apply cannot happen at the same time), therefore the risk of Terraform state file corruption extremely small. In combination with the additional cost of this, this has not been enabled.

* **ID:** [CKV_AWS_119 - Ensure DynamoDB Tables are encrypted using a KMS Customer Managed CMK](https://www.checkov.io/5.Policy%20Index/terraform.html)
  * **Violation Location(s):**
    * [`ddb.tf | resource "aws_dynamodb_table" "locks_table"`](./ddb.tf)
  * **Ignore Justification:** The DynamoDB table only contains locks and the md5 checksum for the Terraform state files. As this data is not sensitive, and everything in DynamoDB is encrypted at rest by default, PCS believe the additonal costs and complexity of using KMS are not worth it for consumers.

* **ID:** [CKV2_AWS_34 - AWS SSM Parameter should be Encrypted](https://www.checkov.io/5.Policy%20Index/terraform.html)
  * **Violation Location(s):**
    * [`ddb.tf | resource "aws_ssm_parameter" "locks_table_arn"`](./ddb.tf)
    * [`kms.tf | resource "aws_ssm_parameter" "cmk_arn"`](./kms.tf)
    * [`s3.tf | resource "aws_ssm_parameter" "remote_state_bucket"`](./s3.tf)
    * [`s3.tf | resource "aws_ssm_parameter" "artifacts_bucket"`](./s3.tf)
  * **Ignore Justification:** The SSM parameters used in this service contain only the ARNs of shared resources required for the 3 modules (`terraform/cloudformation/web-pipeline`) to function. Therefore, the additional complexity and costs associated with this are the reason why this has not been implemented due to the contents not being sensitive, like an API key for example.

* **ID:** [CKV_AWS_18 - Ensure the S3 bucket has access logging enabled](https://www.checkov.io/5.Policy%20Index/terraform.html)
  * **Violation Location(s):**
    * [`s3.tf | resource "aws_s3_bucket" "logging"`](./s3.tf)
  * **Ignore Justification:** This bucket is the destination logging bucket for the rest of the S3 buckets created as part of this service. If logging was enabled on this bucket, there would be an infinite loop of logs being generated, meaning extreme costs.

* **ID:** [CKV_AWS_144 - Ensure that S3 bucket has cross-region replication enabled](https://www.checkov.io/5.Policy%20Index/terraform.html)
  * **Violation Location(s):**
    * [`s3.tf | resource "aws_s3_bucket" "logging"`](./s3.tf)
    * [`s3.tf | resource "aws_s3_bucket" "artifacts"`](./s3.tf)
    * [`s3.tf | resource "aws_s3_bucket" "remote_state"`](./s3.tf)
  * **Ignore Justification:** The resources are designed to be used in the region they are first deployed in. As CodePipeline requires access to these buckets, the additional cost and complexity was not deemed worth it. Furthermore, there is a potenital of data sovereignty requirements to be aware of, and we are utlising the durability and high-availability of the S3 service.

* **ID:** [CKV_AWS_145 - Ensure that S3 buckets are encrypted with KMS by default](https://www.checkov.io/5.Policy%20Index/terraform.html)
  * **Violation Location(s):**
    * [`s3.tf | resource "aws_s3_bucket" "logging"`](./s3.tf)
  * **Ignore Justification:** This bucket is the destination logging bucket for S3 server access logs for the rest of the other S3 buckets. Because of this, only `SSE-S3` (AES256) encryption can be used as per AWS hard set of requirements shown below:
    > Amazon S3 buckets with default bucket encryption using SSE-KMS cannot be used as destination buckets for Logging requests using server access logging. Only SSE-S3 default encryption is supported for server access log destination buckets.

    and

    > You can use default bucket encryption on the target bucket only if you use AES256 (SSE-S3). Default encryption with AWS KMS keys (SSE-KMS) is not supported.

    The documentation pages detailed above can be accessed below:
      * <https://docs.aws.amazon.com/AmazonS3/latest/userguide/bucket-encryption.html>
      * <https://docs.aws.amazon.com/AmazonS3/latest/userguide/enable-server-access-logging.html>

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.1.4 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 3.40.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 3.40.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_iam_pipeline"></a> [iam\_pipeline](#module\_iam\_pipeline) | ./modules/terraform-pipeline | n/a |
| <a name="module_main_pipeline"></a> [main\_pipeline](#module\_main\_pipeline) | ./modules/terraform-pipeline | n/a |
| <a name="module_stackset_pipeline"></a> [stackset\_pipeline](#module\_stackset\_pipeline) | ./modules/cfn-pipeline | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_dynamodb_table.locks_table](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/dynamodb_table) | resource |
| [aws_kms_alias.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/kms_alias) | resource |
| [aws_kms_key.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/kms_key) | resource |
| [aws_s3_bucket.artifacts](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket) | resource |
| [aws_s3_bucket.logging](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket) | resource |
| [aws_s3_bucket.remote_state](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket) | resource |
| [aws_s3_bucket_policy.artifacts](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_policy) | resource |
| [aws_s3_bucket_policy.logging](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_policy) | resource |
| [aws_s3_bucket_policy.remote_state](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_policy) | resource |
| [aws_s3_bucket_public_access_block.artifacts](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_public_access_block) | resource |
| [aws_s3_bucket_public_access_block.logging](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_public_access_block) | resource |
| [aws_s3_bucket_public_access_block.remote_state](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_public_access_block) | resource |
| [aws_ssm_parameter.artifacts_bucket](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_parameter) | resource |
| [aws_ssm_parameter.cmk_arn](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_parameter) | resource |
| [aws_ssm_parameter.locks_table_arn](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_parameter) | resource |
| [aws_ssm_parameter.remote_state_bucket](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_parameter) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_assume_role_session_name"></a> [assume\_role\_session\_name](#input\_assume\_role\_session\_name) | A session name that Terraform uses when assuming the pipeline deployment role | `string` | n/a | yes |
| <a name="input_deploy_role"></a> [deploy\_role](#input\_deploy\_role) | Deployment role used to provision resources declared by Terraform | `string` | n/a | yes |
| <a name="input_project_name"></a> [project\_name](#input\_project\_name) | should be lowercase with words separated by hyphens - e.g. vf-robotics, get-leap | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_tf_locks_dynamodb_table_name"></a> [tf\_locks\_dynamodb\_table\_name](#output\_tf\_locks\_dynamodb\_table\_name) | Outputs the name of the tf locks DynamoDB table for use in terraform state |
| <a name="output_tf_state_encryption_key_arn"></a> [tf\_state\_encryption\_key\_arn](#output\_tf\_state\_encryption\_key\_arn) | KMS key dedicated to encrypting terraform remote state and other CICD artifacts |
| <a name="output_tf_state_region_name"></a> [tf\_state\_region\_name](#output\_tf\_state\_region\_name) | Outputs the region that the S3 bucket and DynamoDB table for tf state reside |
| <a name="output_tf_state_s3_bucket_name"></a> [tf\_state\_s3\_bucket\_name](#output\_tf\_state\_s3\_bucket\_name) | Outputs the name of the S3 bucket that stores terraform remote state files |
<!-- END_TF_DOCS -->