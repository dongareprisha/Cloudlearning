# AWS CI/CD Pipelines Seed Repo

## Introduction

Repository used to create pipelines for customer deliveries via Terraform modules.

Each "module" is analogous to a set of CI/CD pipelines in the target account. The structure of each pipeline is governed by the module. Terraform is used to automatically manage and validate all parameters as well as handle conditional resources.

Includes provisioning of shared pipeline resources (S3 buckets for artifacts/TF remote state with associated CMK & TF locks table in DynamoDB).

## Changelog

* 13/12/2019 - v1.0 - Stable working version demonstrated as per brown bag session to team

* 24/12/2019 - v1.1 - Add lifecycle management to artifact S3 bucket (retention policy for artifacts = 30 days)

* 02/06/2020 - v1.2 - Add steps to cover creation of "seed" deployment roles used by the pipelines

* 25/09/2020 - v2.0 - Updated repo to use Terraform 13 with first class expressions, pipelines are now triggered via CloudWatch Events as opposed to polling and updated README

* 04/10/2020 - v2.1 - Updated repo to use Terraform 0.13.4 and removed more interpolation-only expressions found as part of 0.13.4's deeper search to remove warnings

* 11/02/2021 - v2.2 - Update README to document manual role updates to enable StackSet pipelines

* 24/02/2021 - v2.3 - Added variable `prod_listen_branch_name` to allow users to specify the listening branch on Prod pipelines. For example, CodeCommit initialised repos use `main` instead of `master`. So specifying `prod_listen_branch_name = "main"` inside Prod pipeline module instantiations would ensure that pipeline listens on `main`. If omitted, the default is `master`. Also added `tags` on `aws_codepipeline` Terraform resources along with updating default TF version to 0.14.7.

* 28/06/2021 - v3.0 - Overhauled repo to use latest Terraform version and follow PCS 2.0 Repo structure. Below is a full list of changes:
  * Upgrade Terraform version to 1.0.1
  * Defined `session_name` parameter in `assume_role` blocks to allow easier identification of who/what made changes in CloudTrail logs if pipeline related
  * Updated the structure of the repo to follow that defined in new PCS standards
  * Use `default_tags` as provider level as Terraform resources did not include extra tags
  * CodeBuild image has been updated to use `aws/codebuild/standard:5.0` instead of `aws/codebuild/python:3.5.2` which is now a deprecated image
  * Removed non-required IAM permissions for CodePipelines and Terraform CodeBuild containers
  * Added and updated `README.md`s to modules and root

* 16/11/2021 - v4.0 - Transform repo to use static code analysis tools and improve functionality
  * Upgrade Terraform version to 1.0.11
  * Environment flags (enable_prod etc.) have been removed and replaced with `for_each` simplifying module contents and reducing code
  * tfsec, checkov, tflint and cfn-lint CodeBuild actions have been defined that scan the code in repos for best practices, contributes towards resource standardisation and error checking

* 16/12/2021 - v5.0 - Enhance/Improve functionality
  * Upgrade Terraform version to 1.1.2
  * Terraform State Management has changed to use a `STATE_KEY_PATH` CodeBuild env var containing the a subset of the `key` parameter value for the `backend "s3" {}` with the state file name defined inside the `/scripts/tf_deploy.sh`. So: `terraform init -backend-config="key=${STATE_KEY_PATH}terraform.tfstate"`.
    * The rest of the other parameters for the s3 backend are defined within the `terraform` folder as these are static and do not change. This is because prior we had to create seperate `*.hcl` files to accommodate state for different environments via a `backends/` folder, when in fact the actual parameter doing environment seperation was the `key` parameter. If the `key` wasn't changed when creating a new enviornment, i.e you forgot to change the repo name, env name etc. you risk orphaning a bunch of resources. Therefore, the `-backend-config` flag has changed to: `terraform init -backend-config="key=${STATE_KEY_PATH}terraform.tfstate"`. This improvement now completely automates the tf state environment seperation without human intervention, but allows for flexibility if the name of the tf state file is to be renamed for whatever reason.
  * **BREAKING**: Supports edge case cross-account deployments through a single pipeline, with `account_id` changing from `string` to `list(string)` so `assume_role` permissions for the deployment role can still be locked down to project accounts without using a `*` in replacment of the account section in the IAM role ARN.
  * tfsec, checkov, tflint and cfn-lint CodeBuild actions are now defined in the same level as tf-plan/cf-validate to reduce time taken to run a pipeline.
  * Variablise CodeBuild project timeout values. Default set at "60" as per standard.

## Pipelines

### Types

There are three main types of pipeline:

1. Terraform pipeline
   * `(clone => code-scan => tf-plan => approve => tf-apply)`
2. CloudFormation pipeline (i.e. StackSet deployment)
   * `(clone => code-scan => validate => approve => deploy)`
3. S3 website pipeline
   * `(clone => approve => deploy)`

### Environment Variables

The following pipeline types expose the following environment variables:

#### Terraform

| Variable Name        | Description                                                                                                                   |
|----------------------|-------------------------------------------------------------------------------------------------------------------------------|
| TF_VAR_ENV           | Name of the environment e.g. DEV. Used in ensuring the correct variables files are used etc.                                  |
| ACTION            | Variable used to ensure the correct action is done in terraform actions i.e. plan, apply -auto-approve                        |
| TF_VAR_deploy_role   | ARN of the role to be assumed for the deployment of resources                                                                 |
| STATE_KEY_PATH       | Contains a subset of what is required for the `key` parameter for an `backend "s3" {}` to help ensure tf state env seperation |

#### CloudFormation

| Variable Name        | Description                                                                                                  |
|----------------------|--------------------------------------------------------------------------------------------------------------|
| ENV                  | Name of the environment e.g. DEV. Used in ensuring the correct variables files are used etc.                 |
| DEPLOY_ROLE          | ARN of the role to be assumed for the StackSet deployment of resources defined via CloudFormation templates  |

### Managing Environments and Variables

For a given repo, based on the passed module parameters, multiple pipelines can be created for each environment i.e. repository. This supports the below scenarios:

1. Solution exists only in single environment such as a *prod* only product or service
2. Development has only started so pipeline is only required for *dev* environment
3. Service is mature and requires a pipeline for each environment: *dev*, *pre-prod* and *prod*

## Using the Seed Repo

### Structure

* `buildspec/` - While optional, and not technically required due to buildspec variable option when instanstiating a module, this folder is recomemnded to place all the buildspec files required as part of your CI/CD run (terraform, tflint, checkov, tfsec etc.) in one location to keep the repo looking tidy
  * If this folder is not defined, you **MUST** pass in file paths to the buildspec variables when instantiating a new module so everything works correctly.
* `config/` - Contains Terraform variable files `.tfvars` to assign values to Terraform variables, and also passes in the configuation files of the code check tools.
  * **IMPORTANT: Ensure your config files for the code check tools (you can copy the files in here as a starting point) are defined, otherwise the code-check actions in your pipelines will fail!**
* `modules/` - Contains the CloudFormation, Terraform and Web pipeline modules used to create new pipelines.
* `scripts/` - Contains scripts used in the environment. For example, `tf_deploy.sh` is what the buildspec (`./buildspec/terraform.yml`) executes to run Terraform CLI commands to deploy the pipeline infra and ensure the correct state file is selected for repos with multiple environments.
* `terraform/` - Contains all the Terraform code that provisions foundation infra required for CodePipeline CI/CD deployments using Terraform i.e. S3 artifact, remote state buckets and KMS keys etc.
* `.gitignore` - Basic .gitignore file
* `.terraform-version` - If you are using `tfenv` to deploy the pipeline of pipelines for the first time from the local CLI, this ensures the right version is used automatically.
* `README.md` - Is what you're currently reading!

### Instructions

1. Copy the cloned seed repo from vf-pc-ssops-002 to a different folder locally
   * Sync all remote all changes from remote first for seed repo to ensure latest changes are pulled
     * Example Command on Linux/MacOS: `cd .. && cp -a ./aws-ci-cd-pipelines ./myproject-pipelines`

*You may want to update the default branch of the above to use `main` instead of `master`, as `main` is the replacement for the `master` branch name.*

2. Switch to copy of seed repo and amend git remote details to ensure origin now points to customer repo
   * Command: `git remote set-url origin "https://git-codecommit.$TARGET_REGION.amazonaws.com/v1/repos/$CUSTOMER_REPO_NAME"`

3. Review `#TODO BEFORE SEED DEPLOYMENT` TODOs - These must be reviewed and completed **BEFORE** local terminal deployment

    ***Highly Recommended: `CTRL/CMD + F` and search for all occurances of `#TODO BEFORE SEED DEPLOYMENT` or use `git grep TODO`***

4. Make the seed deployment from your local CLI:

    **Ensure the Terraform version used for seed deployment is the same version stated in `buildspec.yml` ie. 1.0.11**

   * Example seed deployment commands:

       ```bash
        # 1. Ensure you have created the AWS Profile defined in terraform/provider.tf first

        # 2. Log in via SAML2AWS
        saml2aws login

        # 3. Navigate to the Terraform directory
        # Replace <folder_name> with folder name output from Step 1
        cd <folder_name>/terraform

        # 4. Initalise Terraform
        terraform init

        # 5. Update TODOs

        # 6. Terraform Plan
        terraform plan -var-file="../config/PROD.tfvars"

        # 7. Validate Plan

        # 8. Deploy the infra
        terraform apply -var-file="../config/PROD.tfvars"
       ```

5. Following seed deployment, review the `#TODO AFTER SEED DEPLOYMENT` TODOs:
   * Includes uncommenting/deleting lines and adding info about S3/repo/CMK, backend configuration etc.

        ***Highly Recommended: `CTRL/CMD + F` and search for all occurances of `#TODO AFTER SEED DEPLOYMENT` or use `git grep TODO`***

6. Copy the local `terraform.tfstate` from seed deployment to the remote location in S3 as defined in `backends/PROD.hcl` -> `key`. This can be done in two ways:
   1. Have Terraform automatically migrate the state file for you - ***You must have your backend file populated for this to work, which you should have already done***
      1. Run `terraform init -backend-config="../backends/PROD.hcl"`
      2. You will get a prompt similar to the below:

      ```text
        Do you want to copy existing state to the new backend?
          Pre-existing state was found while migrating the previous "local" backend to the
          newly configured "remote" backend. No existing state was found in the newly
          configured "remote" backend. Do you want to copy this state to the new "remote"
          backend? Enter "yes" to copy and "no" to start with an empty state.
      ```

      1. Enter `yes` and Terraform will migrate your state file
   2. If you're having problems with the above, use a command to push the state up yourself using the AWS CLI
    * Command:

        ```bash
        # You can find out the below by checking the terraform outputs for the values of $BUCKET and $CMK_ARN

        # $BUCKET  - Replace with bucket name for remote state
        # $REPO    - The name of the repo the code for the pipelines will be stored in
        # $PROFILE - The name of the AWS Profile that you used to deploy locally
        # #CMK_ARN - The ARN of the CMK used to encrypt state and artefacts

        aws s3 cp terraform.tfstate s3://$BUCKET/$REPO/PROD/terraform.tfstate --profile $PROFILE --sse 'aws:kms' --sse-kms-key-id $CMK_ARN
        ```

7. Once complete, stage/commit all changes and push to CodeCommit via its branch that is mapped to production i.e. `main` or `master`.
    * *NOTE: You will have to ensure your CodeCommit git credential-helper in your global git config is pointing to the right AWS profile before you can push, pull, clone etc. You can check this via: `git config --global --edit` or `~/.gitconfig`*

Following above steps, management of pipelines will now be be done using the master pipeline in AWS CodePipeline. Follow the next section on deploying the seed deployment roles used by all pipelines.

## Code Check Tools

**IMPORTANT: Ensure your config files for the code check tools (you can copy the config files for these tools here, in `./config/`) are defined, otherwise the code-check actions in your pipelines will fail!**

## Creating Pipeline Deployment Roles using CloudFormation Stacksets

### Instructions

Ensure the following for each project account:

* Role = AWSCloudFormationStackSetExecutionRole
* Ensure trust policy is set to include "AWSCloudFormationStackSetAdministrationRole" from the designated Pipeline account for your project

You may want a custom Deployment Role, for your own set of tenants. The next steps will create a new Deployment role :

1. Create a stacksets repo for the project/customer
   * A good example to fork would be from the Robotics project (AWS account = 092851067375, AWS region = "eu-central-1", Repo = "vss-robotics-stacksets")
   Once forked, remove all stackset folders with the exception of `*-deployment-roles`. Amend the stackset folder/script/template as required to reflect project names, accounts etc.
   Do note the name of the custom Role that is defined on the template inside `*-deployment-roles`!

At the moment your accounts only have the "AWSCloudFormationStackSetExecutionRole" and not the new one! So in order to run the initial stackset deployment (which creates the custom role for upcoming deployments), you will need either to deploy it from your local machine (option a), or rely on the existing "...ExecutionRole" to deploy it from the master pipeline (option b).

2a. Trigger creation of the stackset from your local machine

   * To do this, amend the `deploy.py` script by overriding the `get_sts_session` to use your local named profile for the project's management account
      * Example: `return boto3.Session(profile_name="XXX")` where XXX is your local named AWS profile for the project's management account

3a. Once stackset is created from local machine, revert changes to the deploy.py script

4a. To automate management of the project's stacksets, push the repo to the management account and create a stackset pipeline ( e.g. 1-stackset-pipeline.tf ) for the new repo, where you can use the new custom Deployment Role.
   * For an example, refer to the above Robotics management account (repo = "vss-robotics-pipelines")

ALTERNATIVELY

2b. To automate management of the project's stacksets, create a stackset pipeline ( e.g. 1-stackset-pipeline.tf ), defined to use the originally existing "...ExecutionRole", and pointing to the new stackset repo (to be created in next step)

  * Commands:

    ```bash
    git add 1-stackset-pipeline.tf
    git commit -m "Added Stackset Pipeline, to create tenant-specific deployment role"
    git push origin
    ```

3b. push the new stackset repo to the management account CodeCommit:

  * In AWS Web Console, create a new repo (e.g. "<PROJECT_NAME>-stacksets"), with the description `"A repository to store the code for StackSets for <PROJECT_NAME>"`:

    ```bash
    git clone <CLONE_URL>
    cd <CLONE_URL_DIR>
    git pull
    git add .
    git commit -m "Initial StackSet deployment - Create custom deployment role for future deployments"
    git push -u origin
    ```

3b. ( Optional ) Once the deployment stackset is deployed, you may now change the role defined for the stackset pipeline ( e.g. 1-stackset-pipeline.tf ) from the "...ExecutionRole" to the new custom Role.
