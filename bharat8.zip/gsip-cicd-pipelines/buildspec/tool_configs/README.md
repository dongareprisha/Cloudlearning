# `tool_configs/`

Stores the configuration files for tools used in a CI/CD pipeline.

## .checkov.yml

Stores the configuration for when checkov is ran in the checkov-scan CodePipeline stage action in a CodePipeline. Can contain parameters instead of passing via CLI flags.

* Config File Docs: <https://github.com/bridgecrewio/checkov#configuration-using-a-config-file>
* CLI Command Reference: <https://www.checkov.io/2.Basics/CLI%20Command%20Reference.html>

The default configuration for checkov in this service is the following:

* `soft-fail` is set to `true`. This means that if checkov detects any failures, it still returns success. This is to prevent the pipelines from being blocked. This behaviour can be changed, by changing `soft-fail` to `false` is required.
* `quiet` is set to `false`. This means that the output will also show every single passed rule. If you would to change this so only the failed rules are shown in the output, this can be set to `true`.

These options are stored in the `checkov.yml` config file, an example is shown below:

```yaml
---
  soft-fail: true
  quiet: false
```

You can view more info about what can be included in the config file here: <https://github.com/bridgecrewio/checkov#configuration-using-a-config-file>

## .tflint.hcl

Stores the configuration for when TFLint is ran in the tflint-scan CodeBuild stage action in a CodePipeline. Can contain parameters specified here instead of CLI flags. Terraform `*.tfvars` files are still passed via a CLI flag due to the CodeBuild Environment variable `ENV` used to identify `.tfvars` files for use in terraform-plan and terraform-apply CodePipeline actions. In addition the AWS tflint ruleset version is replaced via `sed` as part of the buildspec used for the tflint-scan CodeBuild action. This is so all versions required of tools used in CI/CD can be managed in one place i.e. the buildspec.

Config File Docs: <https://github.com/terraform-linters/tflint/blob/master/docs/user-guide/config.md>

## .trivy.yaml

Stores the config for trivy when ran in the trivy-scan CodeBuild stage action in a code pipeline. Can be configured as per the project requirements.

*Note: This file uses `.yaml` instead of `.yml` - although both represent YAML, trivy expects `.yaml`!*

Config File Docs: <https://aquasecurity.github.io/trivy/v0.45/docs/references/configuration/config-file/>
