# `buildspec/`

- [`buildspec/`](#buildspec)
  - [Commonalities](#commonalities)
    - [PCS IaC Library Support](#pcs-iac-library-support)
    - [Tool Config Files](#tool-config-files)
    - [Common Environment Variables](#common-environment-variables)
  - [Buildspecs](#buildspecs)
    - [checkov.yml](#checkovyml)
      - [Environment Variables](#environment-variables)
    - [terraform.yml](#terraformyml)
      - [Environment Variables](#environment-variables-1)
        - [Terraform State File Management](#terraform-state-file-management)
    - [tflint.yml](#tflintyml)
    - [trivy.yml](#trivyyml)

Stores the buildspec files used to orchestrate CodeBuild container runs in each action within a CodePipeline.

## Commonalities

### PCS IaC Library Support

Inside all of the buildspec, you will see a `pre_build` stage with the following command:

```bash
git config --global url."https://git-codecommit.${AWS_REGION}.amazonaws.com/v1/repos/".insteadOf https://github.vodafone.com/VFGroup-GDC-PCS/
```

This ensures support for PCS IaC Library Modules inside customer pipelines. To be clear, you still have to mirror the modules from GitHub to the customer's CodeCommit environment, but this command means you don't have to edit the `source` parameter of all modules to point to your mirrored CodeCommit repo - this command will automatically do it for you!

### Tool Config Files

The tools support passing in config files, which has been made available for you to be specific for different projects if required, although adhering to one common one is better for standardisation. You can see the config files present for the tools inside the `./tool_configs` folder in this directory.

### Common Environment Variables

Below are common environment variables used throughout each tool.

- `$AWS_REGION` - environment variable in the CodeBuild container by default. Maps to the AWS Region the project is deployed in e.g. `eu-west-1`.

- `$CODEBUILD_SRC_DIR` - environment variable in a CodeBuild container, navigates to the root of the repo.

- `$ENV` - Pulled from the environment variables assigned to the CodeBuild projects in the terraform-plan and terraform-apply stages in a pipeline execution. Used for getting the right variables file for each environment.

`ENV` is a CodeBuild environment variable populated at CodeBuild runtime. This is passed in via the `environments` variable, specifically the key of each object. For example:

```hcl
module "project_name" {

  source = "../modules/terraform-pipeline"

  repository_name = "repo_name" #replace with final name of the repo where all pipelines will be defined
  environments = {
    PROD = {
      account_id    = ["123456789012"]
      pipeline_role = "pipeline-deployment-role"
      branch        = "main"
    },
    PRE-PROD = {
      account_id    = ["456789012345"]
      pipeline_role = "pipeline-deployment-role"
      branch        = "pre-prod"
    }
  }
}
```

In the case above:

* `PROD` is the value for `ENV` for the production pipeline for the repo specified in the `repository_name` variable
* `PRE-PROD` is the value for `ENV` for the pre-prod pipeline for the repo specified in the `repository_name` variable

As a result, you need to ensure that your variable files (`*.tfvars`) in the repo are named accordingly. i.e. `PROD.tfvars`, `PRE-PROD.tfvars`.

## Buildspecs

### checkov.yml

Used in the checkov-scan CodeBuild stage in a CodePipeline. Creates a Python virtual environment and installs checkov inside it as per best practice. Prints out versions for verbosity and to assist in troubleshooting activities.

#### Environment Variables

- `$CHECKOV_VERSION` - environment variable in the CodeBuild project. Maps to the checkov version and allows for `pip` versioning syntax. e.g. `>=2.3.245`.

### terraform.yml

Used in the terraform-plan and terraform-apply CodeBuild stages in a CodePipeline.

#### Environment Variables

- `$ACTION` - contains `plan` or `apply -auto-approve` that is pulled from the environment variables assigned to the CodeBuild projects in the terraform-plan and terraform-apply stages in a pipeline execution.

- `$STATE_KEY_PATH` is an environment variable defined inside CodeBuild Projects associated with the terraform-plan and terraform-apply actions in a CodePipeline. As it is related to how the Terraform State Management works, please read the section below.

##### Terraform State File Management

`$STATE_KEY_PATH` is an environment variable defined inside CodeBuild Projects associated with the terraform-plan and terraform-apply actions in a CodePipeline. It contains a subset of information required for the `key` parameter in a `backend "s3" {}` block, specifically the `repository_name` and the `ENV` value as mentioned just above.

Therefore, it could look like: `"my-repo/PROD/"`. The last part, the state file name, is used inside: `terraform init -backend-config="key=${STATE_KEY_PATH}terraform.tfstate"` which would resolve to: `terraform init -backend-config="key=my-repo/PROD/terraform.tfstate"`.

The other parameters defined as part of an s3 backend are defined in the `../terraform/provider.tf` file as these are static and do not change, it's only the `key` that changes for repos that have multiple environments. This newer method of state management compared to the previous way allows complete automation in ensuring the right `key` is used without human input, and prevents cases where the `key` value forgot to be changed risking orphaned resources when defining a new environment. Lastly, this allows flexibility in cases where the state file name needs to be changed.

### tflint.yml

Used in the tflint-scan CodeBuild stage in a CodePipeline. Ensures Terraform code conforms to a standard across all projects.

#### Environment Variables

- `$TFLINT_VERSION` - Environment variable associated with CodeBuild Project, allows users to specify the version of TFLint they want.

- `$TFLINT_AWS_PLUGIN_VERSION` - Environment variable associated with CodeBuild Project, allows the AWS plugin version for TFLint to be customised per project if required.

### trivy.yml

Used in the trivy-scan CodeBuild stage in a CodePipeline.
