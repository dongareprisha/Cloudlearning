"""Deploy StackSet"""

import logging
from os import environ, getenv
from pprint import pprint
from time import sleep

import boto3
from yaml import safe_load

if logging.getLogger().hasHandlers():
    # The AWS Lambda environment pre-configures a handler logging to stderr. If a handler is
    # already configured, `.basicConfig` does not execute. Thus we set the level directly.
    # Use log.info() etc. in AWS Lambda
    log = logging.getLogger()
    log.setLevel(logging.INFO)
else:
    # Use log.info() etc. if testing locally
    logging.basicConfig(
        format="(%(asctime)s) - [%(levelname)s] - %(message)s",
        datefmt="%d/%m/%Y %H:%M:%S %p %z %Z",
    )
    log = logging.getLogger(__name__)
    log.setLevel(int(getenv("LOG_LVL") or "10"))

# StackSet Details
STACK_SET_NAME = "gsip-cicd-deployment-roles"
STACK_SET_DESCRIPTION = "Deploys AWS IAM Roles to be used in CI/CD pipeline deployments"
STACK_SET_INSTANCE_REGIONS = ["eu-west-1"]
STACK_SET_OP_PREFERENCES = {
    "RegionOrder": STACK_SET_INSTANCE_REGIONS,
    "FailureTolerancePercentage": 0,
    "MaxConcurrentPercentage": 100,
}

# Boto3 Auth
session = boto3.Session()  # profile is derived from AWS_PROFILE in CodeBuild Buildspec

# region_name here is the region the StackSet itself is managed
# can be different to regions where StackSet INSTANCEs are deployed
cf = session.client("cloudformation", region_name=environ["DEPLOY_REGION"])


def check_stack_set_instances(account_ids: list[str]):
    """Function to check if any operations are running on a StackSet instances

    Args:
        account_ids (list[str]): AWS Account IDs
    """
    response = cf.list_stack_instances(StackSetName=STACK_SET_NAME)

    supported_account_ids = []
    unsupported_account_ids = []

    for item in response["Summaries"]:
        if item["Status"] == "INOPERABLE":
            log.warning(
                "Following stack instance requires manual investigation "
                "to fix due to INOPERABLE status!"
            )
            pprint(item)
            log.warning("Skipping account check for above stack instance....")
        elif item["Account"] in account_ids:
            supported_account_ids.append(item["Account"])
        else:
            unsupported_account_ids.append(item["Account"])

    if any(unsupported_account_ids):
        log.warning(
            "Stack instances unsupported for accounts: %s", unsupported_account_ids
        )
        delete_stack_set_instances(unsupported_account_ids)
    else:
        log.info("No stack instances in unsupported accounts")

    missing_account_ids = [x for x in account_ids if x not in supported_account_ids]

    if any(missing_account_ids):
        log.info("Stack instances missing for account(s): %s", missing_account_ids)
        create_stack_set_instances(missing_account_ids)
    else:
        log.info("No missing stack instances")


def delete_stack_set_instances(account_ids: list[str]):
    """Function to delete StackSet instances

    Args:
        account_ids (list[str]): List of AWS Account IDs
    """

    # Check if any operation is happening on current StackSet
    check_stack_set_operations()

    # Wait 15 seconds to prevent concurrent operation IDs on same StackSet
    sleep(15)
    log.info("Deleting stack set instances for tenants: %s", account_ids)

    response = cf.delete_stack_instances(
        StackSetName=STACK_SET_NAME,
        Accounts=account_ids,
        Regions=STACK_SET_INSTANCE_REGIONS,
        RetainStacks=False,
    )

    log.info("Stack instances deleted! Operation Id: %s", response["OperationId"])


def create_stack_set_instances(missing_account_ids: list[str]):
    """Function to create StackSet instances

    Args:
        missing_account_ids (list[str]): AWS Account IDs that do not have StackSet instance
    """

    # Check if any operation is happening on current StackSet
    check_stack_set_operations()

    log.warning("%s missing stack instances!", len(missing_account_ids))

    log.info("Creating stack set instances for accounts: %s", missing_account_ids)

    response = cf.create_stack_instances(
        StackSetName=STACK_SET_NAME,
        Accounts=missing_account_ids,
        Regions=STACK_SET_INSTANCE_REGIONS,
        OperationPreferences=STACK_SET_OP_PREFERENCES,
    )

    log.info("New stack instances created! Operation Id: %s", response["OperationId"])


def check_stack_set():
    """Function to check if a StackSet exists/needs updating"""
    log.info("Checking whether StackSet named %s exists!", STACK_SET_NAME)

    with open(f"{STACK_SET_NAME}/template.yml", "r", encoding="utf-8") as stack:
        if active_stack_set_exists():
            log.info("StackSet exists! Issuing update_stack_set() API call...")
            check_stack_set_operations()

            response = cf.update_stack_set(
                StackSetName=STACK_SET_NAME,
                Description=STACK_SET_DESCRIPTION,
                TemplateBody=stack.read(),
                OperationPreferences=STACK_SET_OP_PREFERENCES,
                Capabilities=["CAPABILITY_NAMED_IAM"],
                Tags=get_tags(),
            )

            log.info("Update issued! Operation Id: %s", response["OperationId"])

        else:
            log.info("StackSet does not exist! Issuing create_stack_set() API call...")

            response = cf.create_stack_set(
                StackSetName=STACK_SET_NAME,
                Description=STACK_SET_DESCRIPTION,
                TemplateBody=stack.read(),
                Capabilities=["CAPABILITY_NAMED_IAM"],
                Tags=get_tags(),
            )

            log.info("Create issued! StackSetId: %s", response["StackSetId"])

    in_progress = True

    while in_progress:
        if active_stack_set_exists():
            in_progress = False
            log.info("StackSet named: %s now exists!", STACK_SET_NAME)
        else:
            sleep(15)


def active_stack_set_exists() -> bool:
    """Function to check whether a StackSet is ACTIVE

    Returns:
        bool: Does StackSet exist yes/no (True/False)
    """
    log.info("Checking whether StackSet named: %s exists/is ready!", STACK_SET_NAME)

    stack_exists = False
    response = cf.list_stack_sets()

    for item in response["Summaries"]:
        if item["StackSetName"] == STACK_SET_NAME and item["Status"] == "ACTIVE":
            stack_exists = True
            break

    return stack_exists


def check_stack_set_operations(show_msg: bool = True) -> bool:
    """Function to check if any operations are running on a StackSet

    Args:
        show_msg (bool, optional): Show message on first call. Defaults to True.

    Returns:
        bool: Call same function but should go to bottom most `else` right away
    """
    if show_msg:
        log.info("Checking that stack set has no running/stopping operations")

    response = cf.list_stack_set_operations(StackSetName=STACK_SET_NAME)

    blocking_operations = [
        x for x in response["Summaries"] if x["Status"] in ["RUNNING", "STOPPING"]
    ]

    if len(blocking_operations) > 0:
        wait_period = 60
        log.info(
            "Stack set operation(s) running or stopping. Retrying in %s seconds...",
            wait_period,
        )
        sleep(wait_period)
        return check_stack_set_operations(False)
    else:
        log.info(
            "No stack set operations running now. Continuing with stack set operations!"
        )


def get_accounts_from_file() -> list[str]:
    """Get all AWS Account IDs for StackSet from external file

    Returns:
        list[str]: List of AWS Accounts IDs from accounts.yml file with StackSet
    """
    with open(f"{STACK_SET_NAME}/accounts.yml", "r", encoding="utf-8") as account_ids:
        accounts = safe_load(account_ids)
        return [account_id["Id"] for account_id in accounts]


def get_tags() -> list[dict[str, str]]:
    """Apply common tags to StackSet and associated instances

    Returns:
        list[dict[str, str]]: AWS Tags in data structure boto3 StackSet function(s) expect
    """
    with open("../stacksets/stackset_tags.yml", "r", encoding="utf-8") as tags:
        data = safe_load(tags)

    # If you want to append/overwrite a tag that is unique to this StackSet
    # Comment out the below and change the values of the 'Key' and 'Value' keys
    # i.e key name and value name.
    data["Tags"].append({"Key": "StackSet", "Value": f"{STACK_SET_NAME}"})

    return data["Tags"]


def main():
    """Entry point"""
    log.info("Starting deployment of: %s", STACK_SET_NAME)

    all_account_ids = get_accounts_from_file()

    log.info(
        "Account IDs detected for %s deployment: %s | %s AWS account(s) to process!",
        STACK_SET_NAME,
        str(all_account_ids),
        len(all_account_ids),
    )

    check_stack_set()
    check_stack_set_instances(all_account_ids)

    log.info("Finished deployment of: %s", STACK_SET_NAME)


if __name__ == "__main__":
    main()
