# GSIP Agency Model StackSets

## Introduction

Repo containing StackSet templates, scripts and other assets for deployment into/across the AWS estate for GSIP Agency Model.

Deployment is automated and occurs on changes to the main branch of this repo which is done via pull requests using AWS CodeCommit / CodePipeline

Deployment is governed using the buildspec files in [`./buildspec`](./buildspec/)!
