# `buildspec/`

Stores the buildspec files used to orchestrate CodeBuild container runs in each action within a CodePipeline.

## cfnlint.yml

Used in the cfn-lint-scan CodeBuild stage in a CodePipeline.

## checkov.yml

Used in the checkov-scan CodeBuild stage in a CodePipeline.

## cf_deploy.yml

Used in the cloudformation-deploy CodeBuild stage in a CodePipeline.

## cf_validate.yml

Used in the cloudformation-validate CodeBuild stage in a CodePipeline.
