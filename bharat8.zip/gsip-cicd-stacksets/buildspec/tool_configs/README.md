# `config/`

Stores the cofiguration files for tools used in a CodePipeline.

## cfnlint.yml

Stores the configuration for when cfn-lint is ran in the cfn-lint-scan CodePipeline stage action in a CodePipeline. Can contain parameters specified here instead of CLI flags. For example, AWS regions to run the linting against to ensure it meets specification.

Config File Docs: <https://github.com/aws-cloudformation/cfn-lint#config-file>

## checkov.yml

Stores the configuration for when checkov is ran in the checkov-scan CodePipeline stage action in a CodePipeline. Can contain parameters instead of passing via CLI flags.

* Config File Docs: <https://github.com/bridgecrewio/checkov#configuration-using-a-config-file>
