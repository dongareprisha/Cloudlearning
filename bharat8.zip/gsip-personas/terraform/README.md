# `terraform/`

Directory where all the Terraform code is stored
