import os
import json
import re
import decimal
import boto3
from boto3.dynamodb.conditions import Key, Attr

# 🆕 — OpenSearch Serverless client
from opensearchpy import OpenSearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(os.environ["DYNAMODB_TABLE"])

# ---------- OpenSearch bootstrap ----------
# • set these two env-vars in Lambda configuration
OS_ENDPOINT = os.environ['OPENSEARCH_ENDPOINT']          # e.g. 8gaprpbaip4d0a1dyat6.eu-west-1.aoss.amazonaws.com
INDEX_NAME  = os.environ.get('OPENSEARCH_INDEX', 'table-index')

region      = os.environ['AWS_REGION']
credentials = boto3.Session().get_credentials()
awsauth     = AWS4Auth(credentials.access_key,
                       credentials.secret_key,
                       region,
                       'aoss',                            # service name for Serverless
                       session_token=credentials.token)

opensearch  = OpenSearch(
    hosts=[{'host': OS_ENDPOINT, 'port': 443}],
    http_auth=awsauth,
    use_ssl=True, verify_certs=True,
    connection_class=RequestsHttpConnection
)
# ------------------------------------------

# --------------------------------------------------------------------------- #
# Helpers                                                                     #
# --------------------------------------------------------------------------- #
class DecimalEncoder(json.JSONEncoder):
    """Convert DynamoDB Decimal values to float for JSON serialisation."""
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return float(o)
        return super().default(o)


def paginated_scan(**scan_kwargs):
    """Return *all* items that match a Scan, handling the 1-MiB pagination."""
    items, last_key = [], None
    while True:
        if last_key:
            scan_kwargs["ExclusiveStartKey"] = last_key
        resp = table.scan(**scan_kwargs)
        items.extend(resp.get("Items", []))
        last_key = resp.get("LastEvaluatedKey")
        if not last_key:
            break
    return items


def paginated_query(**query_kwargs):
    """Return *all* items that match a Query, handling pagination."""
    items, last_key = [], None
    while True:
        if last_key:
            query_kwargs["ExclusiveStartKey"] = last_key
        resp = table.query(**query_kwargs)
        items.extend(resp.get("Items", []))
        last_key = resp.get("LastEvaluatedKey")
        if not last_key:
            break
    return items


def http_response(status, body_obj):
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        },
        "body": json.dumps(body_obj, cls=DecimalEncoder),
    }


# --------------------------------------------------------------------------- #
# Lambda handler                                                              #
# --------------------------------------------------------------------------- #
def lambda_handler(event, context):
    print("Received event:", json.dumps(event))
    # Log authenticated user info if available (populated by the Lambda Authorizer)
    user_identity = event.get("requestContext", {}).get("authorizer", {}).get("principalId")
    if user_identity:
        print(f"Authenticated user: {user_identity}")
        
    qs = event.get("queryStringParameters") or {}
    search_term = qs.get("search_term")
    search_category = qs.get("search_category", "account_id")

    # --------------------  basic validation ----------------------------------
    if not search_term:
        return http_response(400, {"error": "search_term required"})
    if len(search_term) > 100:
        return http_response(400, {"error": "search_term exceeds 100 chars"})

    valid_categories = ["account_id", "cli", "customer_name", "customer_email"]
    if search_category not in valid_categories:
        return http_response(
            400,
            {"error": f"Invalid search_category. Must be one of: {', '.join(valid_categories)}"},
        )

    patterns = {
        "account_id": r"^[0-9]{3,20}$",
        "cli": r"^[A-Za-z0-9\-_+]{3,15}$",
        "customer_name": r"^[A-Za-z0-9\s\-'.]+$",
        "customer_email": r"^[A-Za-z0-9._%+\-@]+$",
    }
    if not re.match(patterns[search_category], search_term):
        return http_response(400, {"error": f"{search_category} failed validation"})

    # --------------------  look-ups ------------------------------------------
    try:
        if search_category == "account_id":
            # exact match on partition key → fast Query
            items = paginated_query(
                KeyConditionExpression=Key("account_id").eq(search_term)
            )

        # elif search_category == "cli":
            # paginated scan with server-side 'contains' (case-sensitive)
        #     items = paginated_scan(
        #        FilterExpression=Attr("cli_list").contains(search_term)
        #    )
        # ---------------- OpenSearch-backed partial search ----------------
        elif search_category in ['customer_email', 'customer_name','cli']:
            # Map UI category -> field name in the index
            #field = 'email' if search_category == 'customer_email' else 'account_name'
            field_map = {
                "cli": "cli_list",
                "customer_email": "email",
                "customer_name": "account_name",
            }
            field = field_map[search_category]

            # Escape Lucene special chars then do prefix search
            escaped = re.sub(r'([+\-=&|><!(){}\[\]^"~*?:\\/])',  r'\\\1', search_term.lower())

            try:
                os_resp = opensearch.search(
                    index=INDEX_NAME,
                    size=50,                                   # cap the result set
                    body={
                        "query": {
                            "simple_query_string": {
                                "query": f"{escaped}*",        # prefix wildcard
                                "fields": [field],
                                "default_operator": "and"
                            }
                        }
                    }
                )
                items = [hit['_source'] for hit in os_resp['hits']['hits']]
            except Exception as e:
                print(f"Error querying OpenSearch: {e}")
                return {
                    "statusCode": 502,
                    "headers": {
                        "Content-Type": "application/json",
                        "Access-Control-Allow-Origin": "*"
                    },
                    "body": json.dumps({"error": "Search backend failure"})
                }
        # ------------------------------------------------------------------
        else:  # safety net
            items = paginated_scan()

    except Exception as exc:  # noqa: BLE001
        print("Error searching DynamoDB:", exc)
        return http_response(500, {"error": f"Internal server error: {exc}"})

    # unify output field name for UI
    for it in items:
        if "email" in it:
            it["customer_email"] = it.pop("email")

    return http_response(200, items)
