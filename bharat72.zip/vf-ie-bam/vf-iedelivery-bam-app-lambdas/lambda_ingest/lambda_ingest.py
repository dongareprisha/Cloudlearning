import os
import json
import boto3
import logging
from datetime import datetime
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # Get environment variables
    dynamodb_table = os.environ['DYNAMODB_TABLE']
    billstore_bucket = os.environ['BILLSTORE_BUCKET']
    ingest_bucket = os.environ['INGEST_BUCKET']
    
    # Initialize AWS clients
    s3 = boto3.client('s3')
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(dynamodb_table)
    
    try:
        # Handle both S3 and API Gateway events
        if 'Records' in event:
            record = event['Records'][0]
            if record.get('eventSource') != 'aws:s3':
                raise ValueError(f"Unexpected event source: {record.get('eventSource')}")
            bucket = record['s3']['bucket']['name']
            key = record['s3']['object']['key']
        else:
            if 'bucket' not in event or 'key' not in event:
                raise ValueError("Missing required fields 'bucket' and 'key' in event")
            bucket = event['bucket']
            key = event['key']
        
        logger.info(f"Processing file: {key} from bucket: {bucket}")
        
        if bucket != ingest_bucket:
            return {
                'statusCode': 400,
                'body': json.dumps('Event bucket does not match ingest bucket')
            }
        
        # Extract the filename from the key (in case there are folders)
        filename = key.split('/')[-1]
        
        # Expect new naming convention: <InvoiceID>_<BillType>.[pdf|json]
        try:
            base, ext = filename.rsplit('.', 1)
            ext = ext.lower()
            invoice_id_from_filename, bill_type_from_filename = base.split('_', 1)
        except Exception as e:
            raise ValueError(f"Filename does not match expected format '<InvoiceID>_<BillType>.[pdf|json]: {filename}") from e

        # If this is a metadata file, simply acknowledge its receipt.
        if ext == 'json':
            logger.info(f"Received metadata file: {filename}")
            return {
                'statusCode': 200,
                'body': json.dumps('Metadata file stored')
            }
        
        # Process PDF file and its metadata
        if ext == 'pdf':
            try:
                # Construct the expected metadata file key by replacing extension with .json.
                metadata_key = key.rsplit('.', 1)[0] + ".json"
                logger.info(f"Looking for metadata file: {metadata_key}")
                metadata_obj = s3.get_object(Bucket=ingest_bucket, Key=metadata_key)
                metadata_content = metadata_obj['Body'].read().decode('utf-8')
                logger.info(f"Raw metadata content: {metadata_content}")
                metadata = json.loads(metadata_content)
                logger.info(f"Parsed metadata: {json.dumps(metadata, indent=2)}")
                
                # Validate that the InvoiceID and BillType from metadata match those from the filename.
                invoice_id = metadata.get('InvoiceID')
                bill_type = metadata.get('BillType')
                if not invoice_id or not bill_type:
                    raise ValueError("Metadata file missing InvoiceID or BillType")
                if str(invoice_id) != invoice_id_from_filename or bill_type.lower() != bill_type_from_filename.lower():
                    raise ValueError("Filename and metadata InvoiceID/BillType mismatch")
                
                # Extract additional fields from metadata
                account_id    = metadata.get('AccountID')
                account_name  = metadata.get('AccountName')
                email         = metadata.get('Email')
                account_type  = metadata.get('AccountType')
                bill_period   = metadata.get('BillPeriod')  # Expecting an object with 'start' and 'end'
                issue_date_raw = metadata.get('IssueDate')   # Expected format: YYYY-MM-DD
                cli_list      = metadata.get('CLIs')
                
                if not all([account_id, account_name, issue_date_raw]):
                    raise ValueError("Metadata file missing one or more required fields: AccountID, AccountName, or IssueDate")
                
                # Parse IssueDate and convert to epoch seconds for numeric storage
                try:
                    issue_date_obj = datetime.strptime(issue_date_raw, '%Y-%m-%d')
                    issue_date_epoch = int(issue_date_obj.timestamp())
                except Exception as ex:
                    raise ValueError(f"Invalid IssueDate format in metadata: {issue_date_raw}") from ex

                # Copy PDF to billstore bucket under the account_id folder
                target_key = f"{account_id}/{filename}"
                logger.info(f"Copying PDF to billstore at: {target_key}")
                s3.copy_object(
                    CopySource={'Bucket': ingest_bucket, 'Key': key},
                    Bucket=billstore_bucket,
                    Key=target_key
                )
                
                # Build the full S3 URL for storage_path
                full_storage_path = f"s3://{billstore_bucket}/{target_key}"
                
                # Prepare item for DynamoDB (primary key: account_id and filename)
                item = {
                    'account_id': account_id,        # Partition Key
                    'filename': filename,            # Sort Key (unique per account)
                    'invoice_id': invoice_id,
                    'issue_date': issue_date_epoch,
                    'storage_path': full_storage_path,
                    'account_name': account_name,
                    'email': email,
                    'account_type': account_type,
                    'bill_period': bill_period,
                    'cli_list': cli_list,
                    'bill_type': bill_type
                }
                logger.info(f"Storing metadata in DynamoDB: {json.dumps(item)}")
                table.put_item(Item=item)
                
                # Verify that the item was successfully written (using a consistent read)
                db_response = table.get_item(
                    Key={'account_id': account_id, 'filename': filename},
                    ConsistentRead=True
                )
                if 'Item' not in db_response:
                    raise ValueError("Item not found in DynamoDB after insertion")
                
                # Delete the processed files from the ingest bucket (both PDF and JSON)
                logger.info("Deleting PDF and metadata from ingest bucket")
                s3.delete_object(Bucket=ingest_bucket, Key=key)
                s3.delete_object(Bucket=ingest_bucket, Key=metadata_key)
                
                return {
                    'statusCode': 200,
                    'body': json.dumps('PDF and metadata processed successfully')
                }
            
            except Exception as e:
                error_message = f"Error processing file: {str(e)}"
                logger.error(error_message)
                
                # Determine target folder based on whether the file is already in /retry
                def determine_target_folder(file_key):
                    # If the key already starts with "retry/", then move to "error/", otherwise "retry/"
                    if file_key.startswith("retry/"):
                        return "error/"
                    else:
                        return "retry/"
                
                # Move the PDF file to the appropriate folder in the ingest bucket
                try:
                    target_folder = determine_target_folder(key)
                    new_pdf_key = f"{target_folder}{filename}"
                    s3.copy_object(
                        Bucket=ingest_bucket,
                        CopySource={'Bucket': ingest_bucket, 'Key': key},
                        Key=new_pdf_key
                    )
                    s3.delete_object(Bucket=ingest_bucket, Key=key)
                    logger.info(f"Moved PDF to {new_pdf_key}")
                except Exception as move_error:
                    logger.error(f"Error moving PDF to {target_folder} folder: {str(move_error)}")
                
                # Move the metadata file to the appropriate folder in the ingest bucket
                try:
                    metadata_filename = metadata_key.split('/')[-1]
                    target_folder = determine_target_folder(metadata_key)
                    new_metadata_key = f"{target_folder}{metadata_filename}"
                    s3.copy_object(
                        Bucket=ingest_bucket,
                        CopySource={'Bucket': ingest_bucket, 'Key': metadata_key},
                        Key=new_metadata_key
                    )
                    s3.delete_object(Bucket=ingest_bucket, Key=metadata_key)
                    logger.info(f"Moved metadata to {new_metadata_key}")
                except Exception as meta_move_error:
                    logger.error(f"Error moving metadata to {target_folder} folder: {str(meta_move_error)}")
                
                return {
                    'statusCode': 500,
                    'body': json.dumps('File processing error. Files moved to retry/error folder.')
                }
        
        # For any unknown file type, simply ignore.
        logger.info(f"Ignoring unknown file type: {filename}")
        return {
            'statusCode': 200,
            'body': json.dumps('Ignored unknown file type')
        }
        
    except Exception as e:
        logger.error(f"Error processing event: {str(e)}")
        raise
