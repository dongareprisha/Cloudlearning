import os
import json
import boto3
import tempfile
import zipfile
from datetime import datetime
from botocore.config import Config

s3 = boto3.client('s3', config=Config(signature_version='s3v4'))

def lambda_handler(event, context):
    print(f"Received event: {json.dumps(event)}")
    
    try:
        # Parse the body from the event (expected to be a JSON string)
        body = event.get('body', '')
        print(f"Raw body: {body}")
        
        if not body or not isinstance(body, str):
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Invalid request body"})
            }
        
        try:
            body = json.loads(body)
        except json.JSONDecodeError as e:
            print(f"Error parsing JSON body: {str(e)}")
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Invalid JSON in request body"})
            }
        
        bills = body.get('bills', [])
        print(f"Found {len(bills)} bills to process")
        
        if not bills:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "No bills specified"})
            }
        
        # Use the first bill's account_id for naming the zip file.
        account_id_for_zip = bills[0].get('account_id', 'unknown')
        
        # Create a temporary directory and zip file
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, "bills.zip")
            with zipfile.ZipFile(zip_path, 'w') as zf:
                for i, b in enumerate(bills):
                    try:
                        account_id = b['account_id']
                        issue_date = b['issue_date']  # Expected as epoch seconds
                        bill_type = b.get('bill_type', 'summary')
                        storage_path = b.get('storage_path')
                        if not storage_path:
                            raise KeyError("storage_path")
                    except KeyError as e:
                        print(f"Missing required field in bill {i}: {str(e)}")
                        return {
                            "statusCode": 400,
                            "body": json.dumps({"error": f"Missing required field in bill {i}: {str(e)}"})
                        }
                    
                    print(f"Processing bill {i+1}/{len(bills)}: account_id={account_id}, issue_date={issue_date}, bill_type={bill_type}")
                    
                    # Extract the S3 key from storage_path (expected format: s3://{BILLSTORE_BUCKET}/{key})
                    bucket = os.environ['BILLSTORE_BUCKET']
                    expected_prefix = f"s3://{bucket}/"
                    if storage_path.startswith(expected_prefix):
                        key = storage_path[len(expected_prefix):]
                    else:
                        key = storage_path
                        
                    try:
                        file_path = os.path.join(tmpdir, f"bill_{i}.pdf")
                        print(f"Downloading from bucket: {bucket}, key: {key}")
                        s3.download_file(bucket, key, file_path)
                        
                        # Format the issue date (for filename, use dd-mm-yyyy)
                        try:
                            if isinstance(issue_date, (int, float)):
                                dt = datetime.utcfromtimestamp(issue_date)
                            else:
                                dt = datetime.strptime(issue_date, '%Y-%m-%dT%H:%M:%SZ')
                            formatted_date = dt.strftime("%d-%m-%Y")
                        except Exception as ex:
                            print(f"Error parsing issue_date: {ex}")
                            formatted_date = issue_date
                        
                        zip_filename = f"{account_id}_{formatted_date}_{bill_type}.pdf"
                        zf.write(file_path, zip_filename)
                    except Exception as e:
                        print(f"Error downloading bill: {str(e)}")
                        return {
                            "statusCode": 404,
                            "body": json.dumps({"error": f"Bill not found: {key}"})
                        }
            
            # Upload the zip file to S3 (temporary storage)
            temp_key = f"temp-downloads/bill_{account_id_for_zip}.zip"
            print(f"Uploading zip file to bucket: {bucket}, key: {temp_key}")
            s3.upload_file(zip_path, bucket, temp_key, ExtraArgs={
                "ContentType": "application/zip",
                "ContentDisposition": f"attachment; filename=bill_{account_id_for_zip}.zip"
            })
            
            # Generate a pre-signed URL valid for 5 minutes (300 seconds)
            presigned_url = s3.generate_presigned_url('get_object', Params={
                'Bucket': bucket,
                'Key': temp_key
            }, ExpiresIn=300)
            
            return {
                "statusCode": 200,
                "body": json.dumps({"downloadUrl": presigned_url}),
                "headers": {
                    "Content-Type": "application/json"
                }
            }
    except Exception as e:
        print(f"Unhandled error: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Internal server error"})
        }
