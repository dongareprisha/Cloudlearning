import os
import boto3
import mimetypes
import base64
import secrets
from urllib.parse import unquote_plus
from botocore.exceptions import ClientError

# Retrieve environment variables
ASSETS_BUCKET      = os.environ.get('ASSETS_BUCKET')
DYNAMODB_TABLE     = os.environ.get('DYNAMODB_TABLE')
BILLSTORE_BUCKET   = os.environ.get('BILLSTORE_BUCKET')
ALLOWED_ORIGINS    = os.environ.get('ALLOWED_ORIGINS', '*')
CLIENT_ID          = os.environ.get('CLIENT_ID', '')
TENANT_ID          = os.environ.get('TENANT_ID', '')
CUSTOM_DOMAIN      = os.environ.get('CUSTOM_DOMAIN', '')
CUSTOM_PORT        = os.environ.get('CUSTOM_PORT', '')
API_GATEWAY_ID     = os.environ.get('API_GATEWAY_ID', '')
CLIENT_REGION      = os.environ.get('CLIENT_REGION')

# Create the S3 client
s3 = boto3.client('s3')

def lambda_handler(event, context):
    """
    Serves static assets from an S3 bucket. When serving text assets (index.html or main.js),
    it replaces placeholder values with environment variable values.
    """
    # --- Determine the requested file path ---

    nonce = secrets.token_urlsafe(16)

    path = None
    if event.get("pathParameters") and event["pathParameters"].get("proxy"):
        path = event["pathParameters"]["proxy"]
    else:
        # For HTTP API v2, use "rawPath" (or fall back to "path")
        raw_path = event.get("rawPath", event.get("path", "/"))
        path = unquote_plus(raw_path)

        # Remove leading slash
        if path.startswith('/'):
            path = path[1:]
    
        # Strip stage name if present
        stage = event.get("requestContext", {}).get("stage")
        if stage and path.startswith(stage + '/'):
            path = path[len(stage) + 1:]

        # Default to index.html if path is empty or ends in /
        if not path or path.endswith('/'):
            path = (path.rstrip('/') + '/index.html') if path else 'index.html'
    
    try:
        # --- Retrieve the file from S3 ---
        s3_response = s3.get_object(Bucket=ASSETS_BUCKET, Key=path)
        body = s3_response['Body'].read()

        # For text files (HTML or JS),  perform placeholder replacement.
        # Adjust the condition if you need to process additional file types.
        if path.endswith("main.js") or path.endswith("index.html"):
            text = body.decode('utf-8')
            text = (text.replace("YOUR_CLIENT_ID", CLIENT_ID)
                        .replace("YOUR_TENANT_ID", TENANT_ID)
                        .replace("YOUR_API_GATEWAY_ID", API_GATEWAY_ID)
                        .replace("YOUR_DYNAMODB_TABLE", DYNAMODB_TABLE)
                        .replace("YOUR_CUSTOM_PORT", CUSTOM_PORT)
                        .replace("YOUR_CUSTOM_DOMAIN", CUSTOM_DOMAIN)
                        .replace("YOUR_REGION", CLIENT_REGION)
                        .replace("YOUR_BILLSTORE_BUCKET", BILLSTORE_BUCKET)
                        .replace("RANDOM_NONCE", nonce))  # Replace RANDOM_NONCE
            body = text.encode('utf-8')

        # Determine the content type; if not provided, guess based on file extension.
        content_type = s3_response.get('ContentType')
        if not content_type:
            content_type, _ = mimetypes.guess_type(path)
            if not content_type:
                content_type = 'application/octet-stream'

        # For text content, return as UTF-8 text; for binary content, return as Base64.
        if content_type.startswith("text/") or content_type in (
            "application/javascript", "application/json", "application/xml"
        ):
            body_str = body.decode('utf-8')
            is_base64 = False
        else:
            body_str = base64.b64encode(body).decode('utf-8')
            is_base64 = True

        print(f"Resolved content_type: {content_type}")
        print(f"is_base64_encoded: {is_base64}")    
        
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": content_type,
                "Access-Control-Allow-Origin": ALLOWED_ORIGINS,
                "X-Frame-Options": "SAMEORIGIN",
                "Strict-Transport-Security": "max-age=604800; includeSubDomains; preload",
                "Referrer-Policy": "strict-origin-when-cross-origin",
                "X-Content-Type-Options": "nosniff",
                "X-XSS-Protection": "1; mode=block",
                "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
                "X-Permitted-Cross-Domain-Policies": "none",
                "Expect-CT": "max-age=86400, enforce",
                "Content-Security-Policy": (
                    f"default-src 'self'; "
                    f"script-src 'self' 'nonce-{nonce}'; "
                    f"style-src 'self' 'nonce-{nonce}'; "
                    f"img-src 'self' https://n.vodafone.ie/ https://www.freepnglogos.com/uploads/vodafone-png-logo/ data:; "
                    f"connect-src 'self' https://login.microsoftonline.com/{TENANT_ID}/ https://login.microsoftonline.com/common/discovery/ https://{API_GATEWAY_ID}.execute-api.{CLIENT_REGION}.amazonaws.com/; "
                    f"font-src 'self'; "
                    f"object-src 'none';"
                )
            },
            "body": body_str,
            "isBase64Encoded": is_base64
        }


    except ClientError as e:
        error_code = e.response['Error'].get('Code', '')
        if error_code in ['NoSuchKey', '404']:
            return {
                "statusCode": 404,
                "headers": {
                    "Content-Type": "text/plain",
                    "Access-Control-Allow-Origin": ALLOWED_ORIGINS
                },
                "body": "File not found"
            }
        else:
            print(f"ClientError: {e}")
            return {
                "statusCode": 500,
                "headers": {
                    "Content-Type": "text/plain",
                    "Access-Control-Allow-Origin": ALLOWED_ORIGINS
                },
                "body": "Internal server error"
            }
    except Exception as ex:
        print(f"Exception: {ex}")
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "text/plain",
                "Access-Control-Allow-Origin": ALLOWED_ORIGINS
            },
            "body": "Internal server error"
        }
