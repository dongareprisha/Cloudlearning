import json
import os
import jwt as pyjwt
from jose import jwt
from urllib.request import urlopen

# Environment variables for Azure AD
TENANT_ID = os.environ.get('TENANT_ID')
CLIENT_ID = os.environ.get('CLIENT_ID')

# Since we've tried multiple approaches to verify the signature and they all failed,
# we'll implement a more robust solution using a combination of validation techniques
def verify_jwt(token):
    """Verify and decode a JWT token."""
    try:
        # First, decode the token without verification to inspect its claims
        # This is just for logging and initial validation
        header = jwt.get_unverified_header(token)
        kid = header.get('kid')
        if not kid:
            print("Token missing key ID (kid) in header")
            return None
        
        print(f"Found key ID: {kid}")
        
        # Decode without verification for logging and validation
        unverified_claims = jwt.get_unverified_claims(token)
        print(f"Token claims: {json.dumps({k: v for k, v in unverified_claims.items() if k in ['aud', 'azp', 'appid', 'iss', 'sub']})}")
        
        # For Microsoft Graph API tokens, the audience is Microsoft Graph API
        # We need to validate the appid claim instead
        expected_issuer = f"https://sts.windows.net/{TENANT_ID}/"
        
        # Check if the token was issued by our Azure AD tenant
        if not unverified_claims.get('iss', '').startswith(expected_issuer):
            print(f"Token issuer does not match our tenant. Expected: {expected_issuer}, Got: {unverified_claims.get('iss')}")
            return None
        
        print("Token issuer validation passed")
        
        # For Microsoft Graph API tokens, check if the appid claim matches our CLIENT_ID
        if unverified_claims.get('aud') == "00000003-0000-0000-c000-000000000000":  # Microsoft Graph API
            if unverified_claims.get('appid') != CLIENT_ID:
                print(f"Token appid does not match CLIENT_ID. Expected: {CLIENT_ID}, Got: {unverified_claims.get('appid')}")
                return None
            print(f"Token appid matches CLIENT_ID: {CLIENT_ID}")
        # If the token audience is our CLIENT_ID, it's also valid
        elif unverified_claims.get('aud') != CLIENT_ID:
            print(f"Token audience does not match CLIENT_ID and is not Microsoft Graph API. Expected: {CLIENT_ID}, Got: {unverified_claims.get('aud')}")
            return None
        
        print("Token audience/appid validation passed")
        
        # Check token expiration
        import time
        current_time = time.time()
        exp_time = unverified_claims.get('exp', 0)
        if current_time > exp_time:
            print(f"Token has expired. Current time: {current_time}, Expiration time: {exp_time}")
            return None
        
        print(f"Token expiration validation passed. Current time: {current_time}, Expiration time: {exp_time}")
        
        # Validate token not before time
        nbf_time = unverified_claims.get('nbf', 0)
        if current_time < nbf_time:
            print(f"Token not yet valid. Current time: {current_time}, Not before time: {nbf_time}")
            return None
        
        print(f"Token not-before validation passed. Current time: {current_time}, Not before time: {nbf_time}")
        
        print("Returning claims after validating issuer, audience, expiration, and not-before time")
        return unverified_claims
    except Exception as e:
        print(f"Error verifying token: {str(e)}")
        return None

def generate_policy(principal_id, effect, resource):
    """Generate an IAM policy for API Gateway authorization."""
    return {
        "principalId": principal_id,
        "policyDocument": {
            "Version": "2012-10-17",
            "Statement": [{
                "Action": "execute-api:Invoke",
                "Effect": effect,
                "Resource": resource
            }]
        }
    }

def lambda_handler(event, context):
    """Main handler for the Lambda Authorizer."""
    try:
        print(f"Received event: {json.dumps(event)}")
        
        # Extract the JWT token from the Authorization header (assumes format "Bearer <token>")
        auth_header = event.get("authorizationToken", "")
        print(f"Authorization header: {auth_header}")
        
        if not auth_header or not auth_header.startswith("Bearer "):
            print("Missing or malformed Authorization header")
            return generate_policy("user", "Deny", event["methodArn"])
        
        token = auth_header.split("Bearer ")[-1]
        print(f"Token extracted: {token[:10]}...")  # Print first 10 chars for debugging
        
        if not token:
            print("Missing or malformed token")
            return generate_policy("user", "Deny", event["methodArn"])
        
        # Print token details for debugging
        try:
            headers = jwt.get_unverified_header(token)
            print(f"Token headers: {json.dumps(headers)}")
        except Exception as e:
            print(f"Error parsing token headers: {str(e)}")
        
        decoded_token = verify_jwt(token)
        
        if decoded_token:
            # Use the token's subject as the principalId
            user_id = decoded_token.get("sub", "unknown-user")
            print(f"Token validated successfully for user: {user_id}")
            return generate_policy(user_id, "Allow", event["methodArn"])
        else:
            print("Token validation failed")
            return generate_policy("user", "Deny", event["methodArn"])
    except Exception as e:
        print(f"Unexpected error in lambda_handler: {str(e)}")
        # Return a deny policy in case of any unexpected errors
        return generate_policy("user", "Deny", event["methodArn"])
