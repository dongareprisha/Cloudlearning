import os
import json
import boto3
from datetime import datetime

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['DYNAMODB_TABLE'])

def scan_full_table():
    items = []
    scan_kwargs = {}
    while True:
        response = table.scan(**scan_kwargs)
        items.extend(response.get('Items', []))
        if 'LastEvaluatedKey' not in response:
            break
        scan_kwargs['ExclusiveStartKey'] = response['LastEvaluatedKey']
    return items

def lambda_handler(event, context):
    try:
        items = scan_full_table()
        print(f"Scanned {len(items)} total records.")
    except Exception as e:
        print(f"Error scanning table: {e}")
        return {"statusCode": 500, "body": json.dumps({"error": "Error scanning table"})}

    now = datetime.utcnow().date()

    for item in items:
        try:
            if 'issue_date' not in item:
                continue

            issue_date_epoch = int(str(item['issue_date']).strip())
            if issue_date_epoch > 1e12:
                issue_date_epoch //= 1000

            issue_date = datetime.utcfromtimestamp(issue_date_epoch).date()
            bill_type = item.get('bill_type', 'summary').strip().lower()
            max_age = 2555 if bill_type == 'summary' else 730
            delta = (now - issue_date).days

            if delta > max_age:
                storage_path = item.get('storage_path')
                if not storage_path:
                    continue

                bucket = os.environ['BILLSTORE_BUCKET']
                expected_prefix = f"s3://{bucket}/"
                s3_key = storage_path[len(expected_prefix):] if storage_path.startswith(expected_prefix) else storage_path

                # Delete from S3
                try:
                    s3.delete_object(Bucket=bucket, Key=s3_key)
                except Exception as e:
                    print(f"Error deleting S3 object {s3_key}: {str(e)}")

                # Delete from DynamoDB
                try:
                    filename = item.get('filename') or storage_path.split('/')[-1]
                    if not filename:
                        continue

                    table.delete_item(Key={
                        'account_id': item['account_id'],
                        'filename': filename
                    })
                    print(f"Deleted old record: {item['account_id']} - {filename} ({delta} days)")
                except Exception as e:
                    print(f"Error deleting DB item for {item['account_id']}: {str(e)}")

        except Exception as e:
            print(f"Error processing item: {str(e)}")
            continue

    return {"statusCode": 200, "body": "Deletion complete"}
