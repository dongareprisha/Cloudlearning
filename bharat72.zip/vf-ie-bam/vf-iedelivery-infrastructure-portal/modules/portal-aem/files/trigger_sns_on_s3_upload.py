import json
import boto3
import datetime

def lambda_handler(event, context):
    # TODO implement
    object_name=event['Records'][0]['s3']['object']['key']
    time_stamp= event['Records'][0]['eventTime']
    sns = boto3.client('sns')
    # Publish a simple message to the specified SNS topic
    response = sns.publish(
       TopicArn='arn:aws:sns:eu-west-1:323874256692:vf-iedelivery-ieportal-prod-author-file-upload',   
       Message='File {File_Name} was uploaded at {Time_Stamp}'.format(File_Name=object_name,Time_Stamp=time_stamp),   
    )
    print(event)
    # Print out the response
    print(response)

    
