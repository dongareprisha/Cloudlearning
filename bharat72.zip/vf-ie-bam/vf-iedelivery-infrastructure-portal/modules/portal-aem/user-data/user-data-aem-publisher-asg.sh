#!/bin/bash
set -x
exec > >(tee /var/log/user-data.log|logger -t user-data -s 2>/dev/console) 2>&1
# SSM Agent
yum -y update https://s3.${Region}.amazonaws.com/amazon-ssm-${Region}/latest/linux_amd64/amazon-ssm-agent.rpm
systemctl restart amazon-ssm-agent

#CW AGENT
yum -y update https://s3.${Region}.amazonaws.com/amazoncloudwatch-agent-${Region}/redhat/amd64/latest/amazon-cloudwatch-agent.rpm
systemctl daemon-reload
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -s -c ssm:${ssm_parameter}
userdel -r cwagent
 
# backup limits.conf
cp /etc/security/limits.conf ~/limits.conf.bak
# increase open file limits
cat << EOF >> /etc/security/limits.conf
# Added per Oracle and Celfocus recommendations
* soft  nofile  8192
* hard  nofile  65536
* soft  nproc   8192
* hard  nproc   16384
* soft  sigpending   257576
* hard  sigpending   257576
* soft  stack   10240
* hard  stack   unlimited
EOF

#ASG setup
INSTANCE_ID=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
LOOP_COUNT=1
NODE_TAGS_OK="false"
NODE_ID=$(aws ec2 describe-instances --region ${Region} --instance-id=$INSTANCE_ID --query='Reservations[].Instances[].{Tags:Tags[?Key == `NODE_ID`] | [0].Value}' --output=text || echo "none")
NODE_FQDN=$(aws ec2 describe-instances --region ${Region} --instance-id=$INSTANCE_ID --query='Reservations[].Instances[].{Tags:Tags[?Key == `NODE_FQDN`] | [0].Value}' --output=text || echo "none")
echo "---"
echo "Fetching EC2 tags..."
echo "---"
while [[ $NODE_TAGS_OK == "false" ]]; do
    echo "Loop count: $LOOP_COUNT"
    echo "---"
    if [[ $(echo "$NODE_ID" | tr '[:upper:]' '[:lower:]') == "none" || $(echo "$NODE_FQDN" | tr '[:upper:]' '[:lower:]') == "none" ]]; then
        echo "NODE_ID and/or NODE_FQDN tags not populated yet, retrying..."
        echo "---"
        NODE_ID=$(aws ec2 describe-instances --region ${Region} --instance-id=$INSTANCE_ID --query='Reservations[].Instances[].{Tags:Tags[?Key == `NODE_ID`] | [0].Value}' --output=text || echo "none")
        NODE_FQDN=$(aws ec2 describe-instances --region ${Region} --instance-id=$INSTANCE_ID --query='Reservations[].Instances[].{Tags:Tags[?Key == `NODE_FQDN`] | [0].Value}' --output=text || echo "none")
    else
        NODE_TAGS_OK="true"
        echo "EC2 tags found"
        echo "NODE_ID: $NODE_ID"
        echo "NODE_FQDN: $NODE_FQDN"
        echo "NODE_TAGS_OK: $NODE_TAGS_OK"
        echo "---"
        # Create a file containing the ID and FQDN for this node.
        echo "$NODE_FQDN" > /node_id.txt
        # Configure the system hostname to macth node FQDN.
        hostnamectl set-hostname "$NODE_FQDN"
        # MOCK: Create a dummy file to signal Ansible playbook completion.
        #       This block should be removed, only used by the PoC to mock Ansible.
        sleep 240
        touch /ansible.done
    fi
    if [[ "$NODE_TAGS_OK" == "false" && $LOOP_COUNT -ge 3 ]]; then
        echo "Failed to query EC2 tags: NODE_ID and NODE_FQDN. Shutting down this instance."
        echo "NODE_ID: $NODE_ID"
        echo "NODE_FQDN: $NODE_FQDN"
        echo "NODE_TAGS_OK: $NODE_TAGS_OK"
        systemctl poweroff
    fi
    sleep 25
    let LOOP_COUNT++
done
echo "Successfully ran user data"